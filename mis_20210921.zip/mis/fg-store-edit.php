<?php
if(!session_id() && !headers_sent()) {
   session_start();
}
    include "dbConnector.php";
?>
<?php 
    //session_start();
   
	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	//	header('location: mobile-receive.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?> 

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

    <title>Mobile Management System - Edit Received Item</title>
   <style>
 
        h4{
            color:white;
        }
        
    </style>
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header header-minimal">
    <div class="header-wrapper">
        <div class="container-fluid">
            <div class="header-inner">
              
                <div class="header-content">
                    <div class="header-bottom">

                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->

</header><!-- /.header -->




    <div class="main">
        <div class="outer-admin">
            <div class="wrapper-admin">

                <div class="content-admin">
                    <div class="content-admin-wrapper">
                        <div class="content-admin-main">
                            <div class="content-admin-main-inner">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            

     <div class="header-logo">
                <div>
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                    </a>
                </div>
                    <div class="col-sm-6 row pull-center">   
                        <h1 style="color: #191970;"> 
                        <strong>Mobile Management System</strong></h1> 
                    </div>
                </div><!-- /.header-logo --> 
                  <div class="page-title">
        <?php  if (isset($_SESSION['username'])) : ?>
         
			<p style="float:right;" > <a href="login.php" style="color: red;" > logout</a> </p>
            <p style="float:right;">Welcome Mr/Mrs <strong><?php echo $_SESSION['username']; ?> </strong></p>
		<?php endif ?>
    </div>                          

 
    <div class="background-white p20 mb50"> 
       <div><a href="dashboard.php" class="btn btn-success pull-right"> HOME </a>
       <a href="admin-dashboard-home.php" class="btn btn-danger pull-right"> BACK </a>
       <div class="col-sm-3" style="float: right;">
                    <input class="form-control" id="myInput" type="text" placeholder="Search..">
            </div>
            </div>
       
            <?php
                /////////////////////// FG QUANTITY COUNT //////////////////////
                $query ="SELECT count(QUANTITY) AS QTY 
                        FROM mobile_receive  
                        WHERE QUANTITY = '1' AND LOCATIONNAME = 'FG Store' ; ";
                $result = $db->query($query) or die( "query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $FGQUANTITY = $row['QTY'];
                        }
                }
                /////////////////////// END OF FG QUANTITY COUNT //////////////////////
     
            ?>
      
 <div class="panel panel-default">
        <div class="panel-heading">
            EDIT FG STORE
             
        </div>  
        <div class="panel-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                      <th>SL</th>
                      <th>BRAND</th>
                      <th>MODEL</th>
                      <th>BATCH</th>
                      <th>QRCODE</th>
                      <th>RECEIVEDATE</th>
                      <th>LOCATION</th>
                      <th>ACTION</th>
                    </tr>
                </thead>
                <tbody id="myTable">

                <?php
            include("dbConnector.php");
            $query ="SELECT * FROM mobile_receive ";
            $result = $db->query($query) or die( "query failed");           
            
            while($test = $result->fetch_assoc())
            {
                $id = $test['RECEIVEID'];   
                //echo $id;
                echo "<tr align='center'>"; 
                echo"<td><font color='black'>" .$test['RECEIVEID']."</font></td>"; 
                echo"<td><font color='black'>" .$test['BRAND']."</font></td>";
                echo"<td><font color='black'>". $test['MODEL']. "</font></td>";
                echo"<td><font color='black'>". $test['BATCH']. "</font></td>";
                echo"<td><font color='black'>". $test['QRCODE']. "</font></td>";
                echo"<td><font color='black'>". $test['RECEIVEDATE']. "</font></td>";   
                echo"<td><font color='black'>" .$test['LOCATIONNAME']."</font></td>";
                echo"<td><a href ='view.php?RECEIVEID=$id' target='_blank'>Edit</a>";
                
                                    
                echo "</tr>";
            }
            //mysql_close($conn);
            ?>
                </tbody>
            </table>
        </div>
    </div>   
    </div>
</div>

                                    </div>
                                </div><!-- /.container-fluid -->
                            </div><!-- /.content-admin-main-inner -->
                        </div><!-- /.content-admin-main -->

                        <div class="content-admin-footer">
                            <div class="container-fluid">
                                <div class="content-admin-footer-inner">
                                    <h5 style="text-align:center;">&copy; 2019 All rights are reserved.</h5>
                                </div><!-- /.content-admin-footer-inner -->
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-footer  -->
                    </div><!-- /.content-admin-wrapper -->
                </div><!-- /.content-admin -->
            </div><!-- /.wrapper-admin -->
        </div><!-- /.outer-admin -->
    </div><!-- /.main -->
</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

<!-- //////////search///////////////////  -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

</body>
</html>
