<?php
//fetch.php
//$connect = mysqli_connect("localhost", "root", "", "stockmanage");
//$request = mysqli_real_escape_string($connect, $_POST["query1"]);
include "dbConnector.php";
$transferEMPID = $_POST["transferToEmpID"];

$selectedEmpInfo = explode("-", $transferEMPID);

$selectedEmpId = trim($selectedEmpInfo[0]);


$query = "SELECT * FROM employee WHERE SL_no = (SELECT SL_no FROM employee WHERE EMPID = " . $selectedEmpId . " AND STATUS = 1)";

$result = mysqli_query($db, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 $data = mysqli_fetch_assoc($result);
 echo json_encode($data);
}

else echo false;

?>