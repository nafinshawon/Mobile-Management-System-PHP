<?php
if(!session_id() && !headers_sent()) {
   session_start();
} 

include "dbConnector.php";
?>
<?php 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>
<?php
	// stock management form input
	if(isset($_POST['assigned'])){

			$ASSIGNDATE    = $_POST["assignDate"];
			$TERRITORY     = $_POST["territory"];
			$EMPID         = $_POST["empID"];
        	$EMPNAME       = $_POST["EmpName"];
        	$MSOGRP        = $_POST["MSOGrp"];
			$LOCATION      = $_POST["location"];
			$BRANCH        = $_POST["dispatchToBranchName"];
			$CONCERNPERSON = $_POST["dispatchToConcernPerson"];
			$CAUSEOFDAMAGE = $_POST["dispatchToCauseOfDamage"];
			$REMARKS       = $_POST["dispatchToRemarks"];
			$HOEMPID	   = $_POST["dispatchToHOEMPID"];
			$HOEMPNAME     = $_POST["dispatchToHOEMPName"];
			$DEPT          = $_POST["dispatchToDept"];
			$LOSTREMARKS   = $_POST["dispatchToLostRemarks"];


			//////////////STATUS SET /////////////////////////
			if($LOCATION == "Employee End"){ $STATUS = "4"; $ASSIGNSTATUS = "1"; }
			else if($LOCATION == "Branch"){ $STATUS = "3"; $ASSIGNSTATUS = " "; }
			else if($LOCATION == "Damage"){ $STATUS = "2"; $ASSIGNSTATUS = " "; }
			else if($LOCATION == "Head Office"){ $STATUS = "5"; $ASSIGNSTATUS = " "; }
			else if($LOCATION == "Lost"){ $STATUS = "6"; $ASSIGNSTATUS = " "; }
			else if($LOCATION == "FG Store"){ $STATUS = "1"; $ASSIGNSTATUS = " "; }
			else $STATUS = "1";


///////////////////////////////////////////////////////////////////////////////////////////////////////
			//if(!empty($_REQUEST["empID"])){
			if($LOCATION == "Employee End"){
				$sql_query ="SELECT EMPID, EMPNAME, ASSIGNSTATUS, TRANSFERSTATUS FROM mobile_dispatch WHERE EMPID ='$EMPID' AND ASSIGNSTATUS = '1' AND TRANSFERSTATUS != '4' ; ";

				$result = $db->query($sql_query) or die( "1st query failed");     
                if($result->num_rows>0){ 
                      
						//echo"ERROR: failed ".mysqli_error($db);
        				//		$message = "Already Assigned !!";
        				//		echo "<script type='text/javascript'>alert('$message');</script>";


  ///////////////////////////////////////////////////////////////////////////////////////////////
  								$sql_query = "SELECT * FROM mobile_dispatch";
								//$result = mysqli_query($db, $sql_query);
								$result=$db->query($sql_query);
								$count=$result->num_rows;
								//$DISPATCHID=$count+0;

								/////////////////get LAST DISPATCHID to insert new DISPATCHID/////////////
								///get max DISPATCHID
        						$sql_query = "SELECT max(DISPATCHID) as MAXDISPATCHID FROM mobile_dispatch ORDER BY DISPATCHID ;" ;
        						$result = $db->query($sql_query) or die( "DISPATCH ID query failed");
        						$row = mysqli_fetch_array($result);
        						if($db->query($sql_query) == TRUE){
           							 //echo "CREATE DATABASE SUCCESSFULLY";
            						$MAXDISPATCHID = $row['MAXDISPATCHID'];
        						}
        						else{
            						echo"DISPATCH ID ERROR:".mysqli_error($db);
        						} 

								///get the last dispatchid from mobile_dispatch table 
        						$sql_query = "SELECT DISPATCHID FROM mobile_dispatch WHERE DISPATCHID = '$MAXDISPATCHID' ;"; 
        						$result = $db->query($sql_query) or die( "Max DISPATCH ID query failed");
        						$row = mysqli_fetch_array($result);
        						if($db->query($sql_query) == TRUE){
            						//echo "CREATE DATABASE SUCCESSFULLY";
            						$LASTDISPATCHID = $row['DISPATCHID'];
            						//echo $row['DISPATCHID'];
        						}
        						else{
            						//echo"ERROR:".mysqli_error($db);
        						} 
        						$DISPATCHID = $LASTDISPATCHID ;
								/////////////////////END of LAST DISPATCHID///////////////////    

								//	$DISPATCHID=$count+1;
        													

								$sql_query	= "DELETE FROM mobile_dispatch
	 											WHERE STATUS = '0' ;";
								$result = $db->query($sql_query) or die( "DELETE query failed");

								if($db->query($sql_query)==TRUE)
								{
									//	$message = "DELETE COMPLETE";
									//	echo "<script type='text/javascript'>alert('$message');</script>";
										
								}
								else
								{
										//echo"ERROR: DELETE".mysqli_error($db);
									//	$message = "OOPS..Request Creation Failed. Try Again";
									//	echo "<script type='text/javascript'>alert('$message');</script>";
										//include "mobile-dispatch.php";
								} 
//header('location: mobile-dispatch.php');
        

                }else{ 
                		
 ///////////////INSERT INTO DISPATCH FOR ASSIGN///////////////////////////
        				$sql_query = "SELECT * FROM mobile_dispatch";
						//$result = mysqli_query($db, $sql_query);
						$result=$db->query($sql_query);
						$count=$result->num_rows;
					//	$DISPATCHID=$count+0;

						/////////////////get LAST DISPATCHID to insert new DISPATCHID/////////////
						///get max DISPATCHID
        				$sql_query = "SELECT max(DISPATCHID) as MAXDISPATCHID FROM mobile_dispatch ORDER BY DISPATCHID ;" ;
        				$result = $db->query($sql_query) or die( "DISPATCH ID query failed");
        				$row = mysqli_fetch_array($result);
        				if($db->query($sql_query) == TRUE){
           					 //echo "CREATE DATABASE SUCCESSFULLY";
            				$MAXDISPATCHID = $row['MAXDISPATCHID'];
        				}
        				else{
							echo"DISPATCH ID ERROR:".mysqli_error($db);
        				} 

						///get the last dispatchid from mobile_dispatch table 
        				$sql_query = "SELECT DISPATCHID FROM mobile_dispatch WHERE DISPATCHID = '$MAXDISPATCHID' ;"; 
        				$result = $db->query($sql_query) or die( "Max DISPATCH ID query failed");
        				$row = mysqli_fetch_array($result);
        				if($db->query($sql_query) == TRUE){
            				//echo "CREATE DATABASE SUCCESSFULLY";
            				$LASTDISPATCHID = $row['DISPATCHID'];
            				//echo $row['DISPATCHID'];
        				}
        				else{
            				//echo"ERROR:".mysqli_error($db);
        				} 
        				$DISPATCHID = $LASTDISPATCHID ;	
						/////////////////////END of LAST DISPATCHID/////////////////// 


						$sql_query	= "UPDATE mobile_dispatch
										SET ASSIGNDATE    = DATE_FORMAT('$ASSIGNDATE','%Y%m%d'),  
											TERRITORY     = '$TERRITORY', 
											EMPID         = '$EMPID', 
											EMPNAME       = '$EMPNAME', 
											MSOGRP        = '$MSOGRP',
											ASSIGNSTATUS  = '$ASSIGNSTATUS', 
											LOCATION      = '$LOCATION', 
											BRANCHNAME    = '$BRANCH', 
											CONCERNPERSON = '$CONCERNPERSON', 
											CAUSEOFDAMAGE = '$CAUSEOFDAMAGE', 
											REMARKS       = '$REMARKS', 
											HOEMPID       = '$HOEMPID', 
											HOEMPNAME     = '$HOEMPNAME', 
											HODEPT        = '$DEPT', 
											LOSTREMARKS   = '$LOSTREMARKS', 
											STATUS        = '$STATUS', 
											TRANSFERSTATUS= ' '
	 									WHERE DISPATCHID = '$DISPATCHID' ;";
						$result = $db->query($sql_query) or die( "2nd update query failed");

						if($db->query($sql_query)==TRUE)
						{
							/*	$message = "Dispatched Successfully";
								echo "<script type='text/javascript'>alert('$message');</script>";  */
								
								//include "mobile-dispatch-display.php";
								//include "mobile-dispatch.php";
						//		header('location: mobile-dispatch.php');
							//	header('location: mobile-dispatch.php');
							//	include "fetchEMPName.php";
						}
						else
						{
								echo"ERROR:".mysqli_error($db);
							/*	$message = "OOPS..Request Creation Failed. Try Again";
								echo "<script type='text/javascript'>alert('$message');</script>"; */
								
								//include "mobile-dispatch.php";
						//		header('location: mobile-dispatch.php');
						} 


								///update quantity
								//get receiveid
						$sql_query	= "SELECT * FROM mobile_dispatch WHERE DISPATCHID = '$DISPATCHID';";
						$result = $db->query($sql_query) or die( "failed");
        				$row = mysqli_fetch_array($result);
    					if($db->query($sql_query) == TRUE){
        					//echo "CREATE DATABASE SUCCESSFULLY";
        					$RECEIVEID = $row['RECEIVEID'];
            				//echo "$MAXRECEIVEID";
    					}
    					else{
        					echo"ERROR:".mysqli_error($db);
    					} 

    					//update quantity of receive
						$sql_query	= "UPDATE mobile_receive
										SET QUANTITY = '0' 
	 									WHERE RECEIVEID = '$RECEIVEID' ;";
						$result = $db->query($sql_query) or die( "query failed");

						if($db->query($sql_query)==TRUE){

							//$message = "Successful";
							//echo "<script type='text/javascript'>alert('$message');</script>";
							//include "mobile-dispatch-display.php";
						}
						else{
							echo"ERROR:".mysqli_error($db);
							//$message = "OOPS..Request Creation Failed. Try Again";
							//echo "<script type='text/javascript'>alert('$message');</script>";
						} 

	            } 
			}else{
			    //end of employee end
			    ///////////////INSERT INTO DISPATCH FOR ASSIGN///////////////////////////
        				$sql_query = "SELECT * FROM mobile_dispatch";
						//$result = mysqli_query($db, $sql_query);
						$result=$db->query($sql_query);
						$count=$result->num_rows;
					//	$DISPATCHID=$count+0;

						/////////////////get LAST DISPATCHID to insert new DISPATCHID/////////////
						///get max DISPATCHID
        				$sql_query = "SELECT max(DISPATCHID) as MAXDISPATCHID FROM mobile_dispatch ORDER BY DISPATCHID ;" ;
        				$result = $db->query($sql_query) or die( "DISPATCH ID query failed");
        				$row = mysqli_fetch_array($result);
        				if($db->query($sql_query) == TRUE){
           					 //echo "CREATE DATABASE SUCCESSFULLY";
            				$MAXDISPATCHID = $row['MAXDISPATCHID'];
        				}
        				else{
							echo"DISPATCH ID ERROR:".mysqli_error($db);
        				} 

						///get the last dispatchid from mobile_dispatch table 
        				$sql_query = "SELECT DISPATCHID FROM mobile_dispatch WHERE DISPATCHID = '$MAXDISPATCHID' ;"; 
        				$result = $db->query($sql_query) or die( "Max DISPATCH ID query failed");
        				$row = mysqli_fetch_array($result);
        				if($db->query($sql_query) == TRUE){
            				//echo "CREATE DATABASE SUCCESSFULLY";
            				$LASTDISPATCHID = $row['DISPATCHID'];
            				//echo $row['DISPATCHID'];
        				}
        				else{
            				//echo"ERROR:".mysqli_error($db);
        				} 
        				$DISPATCHID = $LASTDISPATCHID ;	
						/////////////////////END of LAST DISPATCHID/////////////////// 


						$sql_query	= "UPDATE mobile_dispatch
										SET ASSIGNDATE    = DATE_FORMAT('$ASSIGNDATE','%Y%m%d'),  
											TERRITORY     = '$TERRITORY', 
											EMPID         = '$EMPID', 
											EMPNAME       = '$EMPNAME', 
											MSOGRP        = '$MSOGRP',
											ASSIGNSTATUS  = '$ASSIGNSTATUS', 
											LOCATION      = '$LOCATION', 
											BRANCHNAME    =  '$BRANCH', 
											CONCERNPERSON = '$CONCERNPERSON', 
											CAUSEOFDAMAGE = '$CAUSEOFDAMAGE', 
											REMARKS       = '$REMARKS', 
											HOEMPID       = '$HOEMPID', 
											HOEMPNAME     = '$HOEMPNAME', 
											HODEPT        = '$DEPT', 
											LOSTREMARKS   = '$LOSTREMARKS', 
											STATUS        = '$STATUS', 
											TRANSFERSTATUS= ' '
	 									WHERE DISPATCHID = '$DISPATCHID' ;";
						$result = $db->query($sql_query) or die( "2nd update query failed");

						if($db->query($sql_query)==TRUE)
						{
							/*	$message = "Dispatched Successfully";
								echo "<script type='text/javascript'>alert('$message');</script>";  */
								
								//include "mobile-dispatch-display.php";
								//include "mobile-dispatch.php";
						//		header('location: mobile-dispatch.php');
							//	header('location: mobile-dispatch.php');
							//	include "fetchEMPName.php";
						}
						else
						{
								echo"ERROR:".mysqli_error($db);
							/*	$message = "OOPS..Request Creation Failed. Try Again";
								echo "<script type='text/javascript'>alert('$message');</script>"; */
								
								//include "mobile-dispatch.php";
						//		header('location: mobile-dispatch.php');
						} 


								///update quantity
								//get receiveid
						$sql_query	= "SELECT * FROM mobile_dispatch WHERE DISPATCHID = '$DISPATCHID';";
						$result = $db->query($sql_query) or die( "failed");
        				$row = mysqli_fetch_array($result);
    					if($db->query($sql_query) == TRUE){
        					//echo "CREATE DATABASE SUCCESSFULLY";
        					$RECEIVEID = $row['RECEIVEID'];
            				//echo "$MAXRECEIVEID";
    					}
    					else{
        					echo"ERROR:".mysqli_error($db);
    					} 

    					//update quantity of receive
						$sql_query	= "UPDATE mobile_receive
										SET QUANTITY = '0' 
	 									WHERE RECEIVEID = '$RECEIVEID' ;";
						$result = $db->query($sql_query) or die( "query failed");

						if($db->query($sql_query)==TRUE){

							//$message = "Successful";
							//echo "<script type='text/javascript'>alert('$message');</script>";
							//include "mobile-dispatch-display.php";
						}
						else{
							echo"ERROR:".mysqli_error($db);
							//$message = "OOPS..Request Creation Failed. Try Again";
							//echo "<script type='text/javascript'>alert('$message');</script>";
						} 

			}//end else
			
 	}else{
 		//echo"ERROR new:".mysqli_error($db);
 } ?>	

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

 <!--   <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css"> -->
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
 <!--   <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" > -->
 <!--   <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" > -->
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
 <!--   <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css"> -->
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

 <!--   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">  -->

    <title>Mobile Management System - Mobile Dispatch</title>
        <script type="text/javascript">
        function confSubmit(assignform) {
                if($("#location").val() === ""){
                        alert("Please complete the form");
                }else {
                        if($("#location").val() === "Employee End"){
                                if($("#territory").val() === "" || $("#empID").val() === "" || $("#EmpName").val() === "" || $("#MSOGrp").val() === ""){
                                        alert("Please complete the emplyee information");
                                }else {
                                        if (confirm("Are you sure you want to assign this mobile?")) {
                                                form.submit();
                                                alert("Dispatched Successfully!");
                                        }
                                        else {
                                                alert("You decided not to assign this mobile.");
                                        } 
                                }
                        }//employee end
                        else if($("#location").val() === "Branch"){
                                if($("#dispatchToBranchName").val() === "" || $("#dispatchToConcernPerson").val() === ""){
                                        alert("Please complete the branch information");
                                }else {
                                        if (confirm("Are you sure you want to assign this mobile?")) {
                                                form.submit();
                                                alert("Dispatched Successfully!");
                                        }
                                        else {
                                                alert("You decided not to assign this mobile.");
                                        } 
                                }
                        }//branch
                        else{
                                if($("#dispatchToHOEMPID").val() === "" || $("#dispatchToHOEMPName").val() === "" || $("#dispatchToDept").val() === ""){
                                        alert("Please complete the head office information");
                                }else {
                                        if (confirm("Are you sure you want to assign this mobile?")) {
                                                form.submit();
                                                alert("Dispatched Successfully!");
                                        }
                                        else {
                                                alert("You decided not to assign this mobile.");
                                        } 
                                }
                        }//head office
                           
                }// not null condition end
        }
      
    </script>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"   type="text/javascript"></script>  
<script>
    function showLocation(select_item) {

        if (select_item == "Employee End") {
            $('#dispatchToTerritory').show();
            $('#transferFromEmpID').show();
            $('#dispatchToBranch').hide();
            $('#dispatchToDamage').hide();
            $('#dispatchToHeadOffice').hide();
            $('#dispatchToLost').hide();
        }
        else if (select_item == "Branch") {
            $('#dispatchToBranch').show();
            $('#dispatchToTerritory').hide();
            $('#dispatchToDamage').hide();
            $('#dispatchToHeadOffice').hide();
            $('#transferFromEmployeeInformation').hide();
            $('#dispatchToLost').hide();
          
        }
        else if (select_item == "Damage"){
            $('#dispatchToDamage').show();
            $('#dispatchToBranch').hide();
            $('#dispatchToTerritory').hide();
            $('#dispatchToHeadOffice').hide();
            $('#transferFromEmployeeInformation').hide();
            $('#dispatchToLost').hide();
        }
        else if (select_item == "Head Office") {
            $('#dispatchToHeadOffice').show();
            $('#dispatchToTerritory').hide();
            $('#transferFromEmpID').hide();
            $('#dispatchToBranch').hide();
            $('#dispatchToDamage').hide();
            $('#dispatchToLost').hide();
        }
        else if(select_item == "Lost"){
            $('#dispatchToLost').show();
            $('#dispatchToTerritory').hide();
            $('#transferFromEmpID').hide();
            $('#dispatchToBranch').hide();
            $('#dispatchToDamage').hide();
            $('#dispatchToHeadOffice').hide();
        }
        else {
            $('#dispatchToTerritory').hide();
            $('#transferFromEmployeeInformation').hide();
            $('#dispatchToBranch').hide();
            $('#transferFromFGStore').hide();
            $('#dispatchToDamage').hide();
            $('#dispatchToHeadOffice').hide();
            $('#dispatchToLost').hide();
           
        }
    }
</script>
    <style type="text/css">
        .gst20{
            margin-top:20px;
        }

        #hdTuto_search{
            display: none;
        }

        .list-gpfrm-list a{
            text-decoration: none !important;
        }

        .list-gpfrm li{
            cursor: pointer;
            padding: 4px 0px;
        }

        .list-gpfrm{
            list-style-type: none;
            background: #d4e8d7;
        }

        .list-gpfrm li:hover{
            color: white;
            background-color: #3d3d3d;
        }
       
        h4{
            color:white;
        }
        .button-but2 {
            background-color: #CC3300;  /* Green */
           /* background-color:#009f8b; */
            width:80%;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 50px;
            
            margin-bottom: 25px;
           /* margin: 4px 6px; */
            cursor: pointer;
            -webkit-transition-duration: 0.4s; /* Safari */
            transition-duration: 0.4s;
        }
        
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
        }
        .button2:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        .button3 {
                border-radius: 12px;
        }
        .boxcolor{
            background-color:#003399;
        }
        
    </style>
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header header-minimal">
    <div class="header-wrapper">
        <div class="container-fluid">
            <div class="header-inner">
              
                <div class="header-content">
                    <div class="header-bottom">

                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->

</header><!-- /.header -->




    <div class="main">
        <div class="outer-admin">
            <div class="wrapper-admin">

                <div class="content-admin">
                    <div class="content-admin-wrapper">
                        <div class="content-admin-main">
                            <div class="content-admin-main-inner">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            
   <!-- <div class="page-title">
        <h1>Mobile Transfer</h1>
    </div> -->
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                    </a>
                                            
    <div class="page-title">
        <?php  if (isset($_SESSION['username'])) : ?>
			<p style="float:right;"> <a href="login.php" style="color: red;"> logout</a> </p>
            <p style="float:right;">Welcome Mr/Mrs <strong><?php echo $_SESSION['username']; ?> </strong></p> 
		<?php endif ?>
    </div>
                                            
    <div class="row" style="margin-left: 10%; margin-right: 10%;">
         <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-receive.php">
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Receive</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-dispatch.php">
      
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Dispatch</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-transfer.php">
     
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Mobile Transfer </h4></button>
                 </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-status-report.php">

                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Report </h4></button>
                
         </a>
        </div><!-- /.col-* -->
    </div><!-- /.row -->

    <div class="row" style="margin-left: 10%; margin-right: 10%;">
        <div class="p50 mb30 center col-sm-3"><a href="fg-store-edit.php">
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Edit FG Store</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="employee_end-edit.php">
      
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Edit Emp End</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="head-office-edit.php">
     
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Edit Head Office</h4></button>
                 </a>
        </div><!-- /.col-* -->

     <!--   <div class="p50 mb30 center col-sm-3"><a href="admin-home.php">

                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Main</h4></button>
                
         </a>
        </div> --> <!-- /.col-* -->
    </div><!-- /.row -->

<div class="col-md-3"> </div>
        <div class="col-md-6">
            <div class="background-white p20 mb50">
                  <h2 class="page-title">Mobile Dispatch</h2>
                    <form method="post" action="#" onsubmit="$_SERVER['PHP_SELF']" id="qrLoadForm">
                        
                        <div class="input-group">
			                <label>QR Code<span class="required"></span></label>
			                <input type="text" class="form-control" name="qr_code" id="qr_code"  placeholder="13-15 Digit QR Code" required />
		                    
		                </div>
                       <!-- <input type="button"  id="LoadStock" value="Load">  -->
                        <button type="submit" class="btn btn-primary" name="LoadStock">Load</button> 
                         
                        <?php 

			                if(isset($_REQUEST['LoadStock'])){
    			                $qr_code=$_POST['qr_code'];
                                //$qr_code=isset($_POST['qr_code']) ? $_POST['qr_code'] : '';
                                $sql_query = "SELECT  QRCODE FROM mobile_receive WHERE QRCODE = '$qr_code' ; ";
                                $result = $db->query($sql_query) or die( "failed");
                                $row = mysqli_fetch_array($result);
                                if($db->query($sql_query) == TRUE){
                                    $str1 = $row["QRCODE"];
                                    // echo strlen($str1);
                                    // echo "<br>";
                                    if(strlen($str1) <= '15'){
                                    //  echo "okay. you can use this.";
				                        $sql = "SELECT RECEIVEID, BRAND, MODEL, BATCH, REFERENCE, QRCODE, RECEIVEDATE 
							                    FROM mobile_receive 
							                    WHERE QRCODE = '$qr_code' and QUANTITY = '1';";
				                        $result = $db->query($sql) or die( " QR query failed");
				                        if($result->num_rows>0) {
  				                        ?>
				                            <?php while($row = $result->fetch_assoc())	{
  					 
  				                        ?> 
      <!--     //////////////////QR LOAD END /////////////////////////       -->        
                        <p><span id='display'></span></p>
                        <div class="form-group">
			                <label>Brand</label>
			                <input type="text" class="form-control" name="brand" id="brand" value="<?php echo $row['BRAND']; ?>" placeholder="Brand" readonly required>
		                </div>

		                <div class="form-group">
			                <label>Model</label>
			                <input type="text" class="form-control" name="model" id="model" value="<?php echo $row['MODEL']; ?>" placeholder="Model" readonly required>
		                </div>
		                <div class="form-group">
			                <label>Batch</label>
			                <input type="text" class="form-control" name="batch" id="batch" value="<?php echo $row['BATCH']; ?>" placeholder="Batch" readonly required>
		                </div>
		                <div class="form-group">
			                <label>Reference</label>
			                <input type="text" class="form-control" name="reference" id="reference" value="<?php echo $row['REFERENCE']; ?>" placeholder="Reference" readonly required>
		                </div> 
                        
                                        <?php  } //while($row = $result->fetch_assoc())

                                    }else { 
                                        $sql = "SELECT RECEIVEID, BRAND, MODEL, BATCH, REFERENCE, QRCODE, RECEIVEDATE 
                                                FROM mobile_receive 
                                                WHERE QRCODE = '$qr_code' and QUANTITY = '0';";
                                                $result = $db->query($sql) or die( " QR query failed");
                                                if($result->num_rows>0) {
                                                    echo '<span style="color:red ;text-align:center;"><strong>Already Assigned!</strong></span>';
                                                }else{
                                                    echo '<span style="color:red ;text-align:center;"><strong>Wrong Input</strong></span>';   
                                                }
                                    }//if($result->num_rows>0) close 
                                }else{
                                    echo '<span style="color:red ;text-align:center;"><strong>QRCODE must be 13-15 digits.</strong></span>';
                                    // echo "";
                                }//if(strlen($str1) <= '15')
                                ?>
                        <?php  
                            }else { ?>  
                                <?php }//if($db->query($sql_query) == TRUE) ?>
                        <?php  
                        }else { ?>  

                    <?php }//if(isset($_REQUEST['LoadStock'])) ?>
        
        
        
        </form>
         <?php include "qr-load.php" ?>   
        <!-- //////// qrinfo fetch done  ///////////  -->
         <form method="post" action="" name="assignform">               
                        <div class="form-group">
                        <label for="select_location">Location</label>
                         <select class="form-control" name="location" id="location" 
                                    onchange="java_script_:showLocation(this.options[this.selectedIndex].value)"> 
                                    <option value="">Select Location</option> 
                           
                            <?php
                                $sql_query = mysqli_query($db,"select LOCATIONID, LOCATIONNAME from location 
                                                                where LOCATIONNAME <> 'FG Store' 
                                                                    AND LOCATIONNAME <> 'Damage' 
                                                                    AND LOCATIONNAME <> 'Lost' 
                                                                    AND LOCATIONNAME <> 'Mature' 
                                                                    order by LOCATIONNAME; ");

                                  
                                while($row = mysqli_fetch_array($sql_query)){
                                echo "<option value='".$row['LOCATIONNAME']."'>".$row['LOCATIONNAME']."</option>";
                                }
                            ?>
                        </select>
                        </div>  
                        
            <div id="dispatchToTerritory" style="display: none"> <!-- dispatchToTerritory Fields -->
<!-- <label>Territory</label>
     <input type="text" name="territory" id="territory" class="form-control input-lg" autocomplete="off" placeholder="Type Territory" />
     <br /><br />
     <label>EMPID</label>
     <input type="text" name="empID" id="empID" class="form-control input-lg" autocomplete="off" placeholder="Type Employee ID or Name" />
     <label>EMP NAME</label>
     <input type="text" name="EmpName" id="EmpName" class="form-control input-lg" autocomplete="off" placeholder="EMP NAME" />
     <label>MSO GROUP</label>
     <input type="text" name="MSOGrp" id="MSOGrp" class="form-control input-lg" autocomplete="off" placeholder="MSOGRP" /> -->


                            <div class="form-group">
                                <label for="territory">Territory</label>
                                        <input type="text" class="form-control" name="territory" id="territory" placeholder="Territory" autocomplete="off">
                            </div> <!-- /.end of territory div -->

                            <div class="form-group">
                               <label>Emp ID</label>
                                    <input type="text" class="form-control" name="empID" id="empID" placeholder="Emp ID" autocomplete="off">
                            </div> <!-- /.end of emp ID div -->


                            <div class="form-group">
                                <label>Emp Name </label>
                                <input type="text" class="form-control" name="EmpName" id="EmpName" placeholder="Employee Name" value="" autocomplete="off" >
                            </div>  <!-- /.end of Emp Name div -->

                            <div class="form-group">
                                <label>MSO Group </label>
                                <input type="text" class="form-control" name="MSOGrp" id="MSOGrp" placeholder="Group" value="" autocomplete="off">
                            </div>  <!-- /.end of MSO GRP div -->
            </div><!-- dispatchToTerritory Fields -->
                        
            <div id="dispatchToBranch" style="display: none"> <!-- /.dispatchToBranch -->
                        <div class="form-group">
                            <label for="dispatchToBranchName">Branch Name</label>
                            <input type="text" class="form-control" name="dispatchToBranchName" id="dispatchToBranchName" placeholder="Branch Name" >
                        </div>
                        
                        <div class="form-group">
                            <label for="dispatchToConcernPerson">Concern Person </label>
                            <input type="text" class="form-control" name="dispatchToConcernPerson" id="dispatchToConcernPerson" placeholder="Concern Person" >
                        </div>
            </div>   <!-- /.dispatchToBranch -->

            <div id="dispatchToDamage" style="display: none"> <!-- /.dispatchToDamage -->
                         <div class="form-group">
                            <label for="dispatchToCauseOfDamage">Cause of Damage</label>
                            <input type="text" class="form-control" name="dispatchToCauseOfDamage" id="dispatchToCauseOfDamage" placeholder="Cause of Damage" >
                        </div><!-- /.form-group -->
                        
                        <div class="form-group">
                            <label for="dispatchToRemarks">Remarks</label>
                            <input type="text" class="form-control" name="dispatchToRemarks" id="dispatchToRemarks" placeholder="Remarks" >
                        </div><!-- /.form-group -->
            </div> <!-- /.dispatchToDamage -->
            
            <div id="dispatchToHeadOffice" style="display: none"> <!-- /.dispatchToHeadOffice  -->
                         <div class="form-group">
                            <label for="dispatchToHOEMPID">EMP ID</label>
                            <input type="text" class="form-control" name="dispatchToHOEMPID" id="dispatchToHOEMPID" placeholder="EMP ID" >
                        </div><!-- /.form-group -->
                        
                        <div class="form-group">
                            <label for="dispatchToHOEMPName">EMP Name</label>
                            <input type="text" class="form-control" name="dispatchToHOEMPName" id="dispatchToHOEMPName" placeholder="EMP Name" >
                        </div><!-- /.form-group -->

                        <div class="form-group">
                            <label for="dispatchToDept">Department</label>
                            <input type="text" class="form-control" name="dispatchToDept" id="dispatchToDept" placeholder="Department" >
                        </div><!-- /.form-group -->
            </div> <!-- /.dispatchToHeadOffice -->
            
            <div id="dispatchToLost" style="display: none"> <!-- /.dispatchToLost -->
                         <div class="form-group">
                            <label for="dispatchToLostRemarks">Remarks</label>
                            <input type="text" class="form-control" name="dispatchToLostRemarks" id="dispatchToLostRemarks" placeholder="Remarks" >
                        </div><!-- /.form-group -->
            </div> <!-- /.dispatchToLost -->
 
                            
                    <div class="form-group" >
                        <label for="">Date</label>
                        <input type="date" class="form-control" name="assignDate" id="assignDate" placeholder="Assign Date" value=""  >
                    </div><!-- /.form-group -->
                        
                    
              <button type="submit" class="btn btn-primary" name="assigned" onClick="confSubmit(this.form);">Assign</button>
                </form>
            </div>
        </div>
</div>

                                    </div>
                                </div><!-- /.container-fluid -->
                            </div><!-- /.content-admin-main-inner -->
                        </div><!-- /.content-admin-main -->

                        <div class="content-admin-footer">
                            <div class="container-fluid">
                                <div class="content-admin-footer-inner">
                                    <h5 style="text-align:center;">&copy; 2019 All rights are reserved.</h5>
                                </div><!-- /.content-admin-footer-inner -->
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-footer  -->
                    </div><!-- /.content-admin-wrapper -->
                </div><!-- /.content-admin -->
            </div><!-- /.wrapper-admin -->
        </div><!-- /.outer-admin -->
    </div><!-- /.main -->
</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>

<script>
    //TERRITORY SEARCH
  $(document).ready(function(){
           
      $('#territory').typeahead({
          source: function(query, result)
          {
              $.ajax({
                  url:"mysqTerritory.php",
                  method:"POST",
                  data:{query:query},
                  dataType:"json",
                  success:function(data)
                  {
                      result($.map(data, function(item){
                        console.log(item);
                          return item;
                      }));
                  }
              })
          }
      });

  });
// TERRITORY SEARCH END
  </script>

  <script>
    //EMPID SEARCH AND FETCH EMPNAME
  $(document).ready(function(){
      $('#empID').typeahead({
          source: function(query, result)
          {
              $.ajax({
                  url:"mysql.php",
                  method:"POST",
                  data:{query:query},
                  dataType:"json",
                  success:function(data)
                  {
                      result($.map(data, function(item){
                          return item;
                      }));
                  }
              })
        }
    });

    var $input = $('#empID');

    $input.change(function() {
          var selectedEmp = $input.typeahead("getActive");

          $.ajax({
               url:"getEMPINFO.php",
               method:"POST",
               data: 'empID='+selectedEmp,
                // data:{query:query1},
              dataType:"json",
              success:function(data)
              {
              		
                    $("#EmpName").val(data.FFNAME);
                    $("#MSOGrp").val(data.MSOGROUP);
                  //  $("#QRCODE").val(data.QRCODE);

            }
        });
    });
   
  });
   //EMPID SEARCH AND FETCH EMPNAME END
  </script>