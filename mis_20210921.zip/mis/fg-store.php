<?php
//include database configuration file
include 'dbConnector.php';

$date1= date("Y/m/d");
$sysDate1 = explode('/', $date1);
$date1year = trim($sysDate1[0]);
$date1month = trim($sysDate1[1]);
$date1day = trim($sysDate1[2]);

//get records from database
$query = $db->query("SELECT p.RECEIVEID, p.BRAND, p.MODEL, p.BATCH, p.REFERENCE, p.QRCODE, p.RECEIVEDATE, p.LOCATIONNAME, p.QUANTITY,
                                                re.TERRITORY, re.EMPID, re.LOCATION, re.DISPATCHID, re.ASSIGNDATE
                                        FROM mobile_receive p 
                                        LEFT JOIN mobile_dispatch re ON re.RECEIVEID = p.RECEIVEID
                                        WHERE p.QUANTITY = '1' AND p.LOCATIONNAME = 'FG Store' OR re.LOCATION = 'FG Store' ;");

if($query->num_rows > 0){
    $delimiter = ",";
    $filename = "fg_store_" . date('Y-m-d') . ".csv";
    
    //create a file pointer
    $f = fopen('php://memory', 'w');
    
   
    
    //set column headers
    $fields = array('BRAND', 'MODEL', 'QRCODE', 'REFERENCE', 'BATCH', 'LOCATIONNAME', 'RECEIVEDATE', 'DURATION');
    fputcsv($f, $fields, $delimiter);
    
    //output each row of the data, format line as csv and write to file pointer
    while($row = $query->fetch_assoc()){
        $RECEIVEDATE = $row['RECEIVEDATE'];
                            $mobilereceiveDate2 = explode('-', $RECEIVEDATE);
                            $date2year = trim($mobilereceiveDate2[0]);
                            $date2month = trim($mobilereceiveDate2[1]);
                            $date2day = trim($mobilereceiveDate2[2]);
                            //end of get receive date from database

                            //find duration
                            // leap year check
                            if((0 == $date2year % 4) & (0 != $date2year % 100) | (0 == $date2year % 400))
                            {
                                    // echo "$year is a Leap Year."; 
                                    if($date1year <= $date2year){
                                        $year = $date1year-$date2year;
                                        $month = $date1month-$date2month;
                                        $day = $date1day-$date2day;
                                    }
                                    elseif($date1year > $date2year){
                                            
                                        //$month = $date1month-$date2month;
                                            if($date2month == '12'){
                                                $year = $date1year-$date2year-1;
                                                $month = $date1month;
                                                $day = $date1day-$date2day;
                                            }
                                            elseif($date1month < $date2month){
                                                $year = $date1year-$date2year-1;
                                                $month = $date1month+('12'-$date2month);
                                                $day = $date1day-$date2day;
                                            }
                                            elseif($date2month == '2'){
                                                $year = $date1year-$date2year;
                                                $month = $date1month-$date2month-1;
                                                $day = $date1day+('31'-$date2day)-1;
                                            }
                                            else{
                                                // $month = $date1month;
                                                $year = $date1year-$date2year;
                                                $month = $date1month-$date2month;
                                                $day = $date1day-$date2day;
                                            }// month != 12
                                            //$day = $date1day-$date2day;
                                    }
                                    else{
                                        $year = $date1year-$date2year-1;
                                        $day = $date1day-$date2day;
                                
                                        if($date1month == $date2month){
                                            $month = $date1month-$date2month+1;
                                        }
                                        else{
                                            $month = $date1month;
                                        }// current month & entry month same
                                    } //no condition applied
                            } //leap year close 
                            else  
                            {  
                                    //echo "$year is not a Leap Year.";    
                                    if($date1year < $date2year){
                                        $year = $date1year-$date2year-1;
                                        $month = $date1month-$date2month;
                                        $day = $date1day-$date2day;
                                    }
                                    elseif($date1year == $date2year){
                                        $year = $date1year-$date1year;
                                        $month = $date1month-$date2month;
                                        $day = $date1day-$date2day;
                                    }
                                    elseif($date1year > $date2year){
                                
                                        //$month = $date1month-$date2month;

                                            if($date2month == '12'){
                                                $year = $date1year-$date2year-1;
                                                $month = $date1month;
                                                $day = $date1day-$date2day+1;
                                            }
                                            elseif($date1month < $date2month){
                                                $year = $date1year-$date2year-1;
                                                $month = $date1month+('12'-$date2month);
                                                $day = $date1day-$date2day;
                                            }
                                            else{
                                                // $month = $date1month;
                                                $year = $date1year-$date2year;
                                                $month = $date1month-$date2month;
                                                $day = $date1day-$date2day;
                                            }// month != 12
                                            
                                    }
                                    else{
                                        $year = $date1year-$date2year-1;
                                        $day = $date1day-$date2day+1;
                                
                                        if($date1month == $date2month){
                                            $month = $date1month-$date2month+1;
                                        }
                                        else{
                                            $month = $date1month;
                                        }// current month & entry month same
                                    } //no condition applied
                            } //leap year close  
                            //end of find duration
                            
        //$STATUS = ($row['STATUS'] == '1')?'Active':'Inactive';
        $lineData = array($row['BRAND'], $row['MODEL'], $row['QRCODE'], $row['REFERENCE'], $row['BATCH'], $row['LOCATIONNAME'], $row['RECEIVEDATE'], "$year"."Y "."$month"."M "."$day"."D ");
        fputcsv($f, $lineData, $delimiter);
    }
    
    //move back to beginning of file
    fseek($f, 0);
    
    //set headers to download file rather than displayed
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '";');
    
    //output all remaining data on a file pointer
    fpassthru($f);
}
else{
    echo "No Data Found.";
}
exit;

?>