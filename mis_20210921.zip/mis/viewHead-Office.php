<?php
require("dbConnector.php");
$id =$_REQUEST['DISPATCHID'];

$query ="SELECT p.RECEIVEID, p.BRAND, p.MODEL, p.BATCH, p.REFERENCE, p.QRCODE, p.RECEIVEDATE,
                                                re.HOEMPNAME, re.HOEMPID, re.HODEPT, re.LOCATION, re.DISPATCHID, re.ASSIGNDATE, re.RECEIVEID
                                        FROM mobile_receive p 
                                        LEFT JOIN mobile_dispatch re ON re.RECEIVEID = p.RECEIVEID
                                        WHERE DISPATCHID  = '$id' and LOCATION = 'Head Office' AND p.LOCATIONID = '1' AND re.STATUS = '5' ; ";


$result = $db->query($query) or die( "dispatchid query failed");           
$test = $result->fetch_assoc();
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$DISPATCHID = $test['DISPATCHID'] ;
				$BRAND = $test['BRAND'] ; 
				$MODEL = $test['MODEL'];				
				$HOEMPID = $test['HOEMPID'] ;
				$HOEMPNAME = $test['HOEMPNAME'];
				$HODEPT = $test['HODEPT'] ;
				$LOCATION = $test['LOCATION'];
				$ASSIGNDATE = $test['ASSIGNDATE'];
				$RECEIVEID = $test['RECEIVEID'] ;

if(isset($_POST['save']))
{	
	//$RECEIVEID_save = $_POST['DISPATCHID'];
	$BRAND_save = $_POST['BRAND'];
	$MODEL_save = $_POST['MODEL'];
	$HOEMPID_save = $_POST['HOEMPID'];
	$HOEMPNAME_save = $_POST['HOEMPNAME'];
	$HODEPT_save = $_POST['HODEPT'];
	$LOCATION_save = $_POST['LOCATION'];
	$ASSIGNDATE_save = $_POST['ASSIGNDATE'];

$query ="UPDATE mobile_receive 
			SET  	BRAND ='$BRAND_save', 
		 			MODEL ='$MODEL_save'
		 			WHERE RECEIVEID = '$RECEIVEID'";
$result = $db->query($query) or die( "receive update query failed");

$query ="UPDATE mobile_dispatch 
			SET  	HOEMPID ='$HOEMPID_save', 
		 			HOEMPNAME ='$HOEMPNAME_save', 
		 			HODEPT ='$HODEPT_save',
		 			LOCATION ='$LOCATION_save',
		 			ASSIGNDATE = '$ASSIGNDATE_save'
		 			WHERE DISPATCHID = '$id'";
$result = $db->query($query) or die( "update query failed");

//	echo "Saved!";
	//include "employee_end-edit.php";
//	header("Location: fg-store-edit.php");			
}
//mysql_close($db);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
<link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">
<title>Mobile Management System - Edit Dispatched Item</title>
</head>

<body>
<form method="post">
<table>
    <tr>
		<td>DISPATCHID</td>
		<td><input type="text" name="DISPATCHID" value="<?php echo $DISPATCHID ?>" readonly/></td>
	</tr> 
	<tr>
		<td>BRAND</td>
		<td><input type="text" name="BRAND" value="<?php echo $BRAND ?>" /></td>
	</tr>
	<tr>
		<td>MODEL</td>
		<td><input type="text" name="MODEL" value="<?php echo $MODEL ?>" /></td>
	</tr>
	<tr>
		<td>EMPID</td>
		<td><input type="text" name="HOEMPID" value="<?php echo $HOEMPID ?>"/></td>
	</tr>
	<tr>
		<td>HOEMPNAME</td>
		<td><input type="text" name="HOEMPNAME" value="<?php echo $HOEMPNAME ?>"/></td>
	</tr>
	<tr>
		<td>HODEPT</td>
		<td><input type="text" name="HODEPT" value="<?php echo $HODEPT ?>"/></td>
	</tr>
	<tr>
		<td>LOCATION</td>
		<td><input type="text" name="LOCATION" value="<?php echo $LOCATION ?>" readonly/></td>
	</tr>
	<tr>
		<td>ASSIGNDATE</td>
		<td><input typr="text" name="ASSIGNDATE" value="<?php echo $ASSIGNDATE ?>"/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>

</body>
</html>
