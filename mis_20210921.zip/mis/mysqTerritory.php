<?php
include "dbConnector.php";

$request = mysqli_real_escape_string($db, $_POST["query"]);
$sql_query = "SELECT DISTINCT TRCODE FROM employee WHERE TRCODE LIKE '%".$request."%' AND STATUS = '1'  ";
//$query = "SELECT DISTINCT TRCODE FROM employee WHERE TRCODE='CCB13' AND STATUS = '1'  ";

$result = mysqli_query($db, $sql_query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
 // $data[] = $row["EMPID"];
 // $data[] = $row["FFNAME"];
  $data[] = $row["TRCODE"];
 }
 echo json_encode($data);
}

?>