<?php
if(!session_id() && !headers_sent()) {
   session_start();
}
    include "dbConnector.php";
?>
<?php 
    //session_start();
   
	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	//	header('location: admin-mobile-receive.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?> 

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

    <title>Mobile Management System - Mobile Receive</title>
    <script type="text/javascript">
         function confSubmit(receiveform) {
                if($("#brand").val() === "" || $("#model").val() === "" || $("#batch").val() === "" || $("#qr_code").val() === "" || $("#receiveDate").val() === ""){
                    
                        alert("Please complete the form");
                
                        
                }else {
                           if (confirm("Are you sure you want to receive this mobile?")) {
                            form.submit();
                            alert("Dispatched Successfully!");
                        }
                        else {
                            alert("You decided not to receive this mobile.");
                        } 
                    }
        }
    </script>
    <style>
        h4{
            color:white;
        }
        .button-but2 {
            background-color: #CC3300;  /* Green */
           /* background-color:#009f8b; */
            width:80%;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 50px;
            
            margin-bottom: 25px;
           /* margin: 4px 6px; */
            cursor: pointer;
            -webkit-transition-duration: 0.4s; /* Safari */
            transition-duration: 0.4s;
        }
        
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
        }
        .button2:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        .button3 {
                border-radius: 12px;
        }
        .boxcolor{
            background-color:#000099;
        }
        
    </style> 
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header header-minimal">
    <div class="header-wrapper">
        <div class="container-fluid">
            <div class="header-inner">

                <div class="header-content">
                    <div class="header-bottom">
                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->

 
</header><!-- /.header -->




    <div class="main">
        <div class="outer-admin">
            <div class="wrapper-admin">


                <div class="content-admin">
                    <div class="content-admin-wrapper">
                        <div class="content-admin-main">
                            <div class="content-admin-main-inner">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-12">
  <!--  <div class="page-title">
        <h1>Mobile Receive</h1>
    </div> -->
    <div class="header-logo">
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                    </a>
                </div><!-- /.header-logo -->
    <div class="page-title">
        <?php  if (isset($_SESSION['username'])) : ?>
			<p style="float:right;"> <a href="login.php" style="color: red;"> logout</a> </p>
            <p style="float:right;">Welcome Mr/Mrs <strong><?php echo $_SESSION['username']; ?> </strong></p> 
		<?php endif ?>
    </div>
                                            
    <div class="row" style="margin-left: 10%; margin-right: 10%;">
         <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-receive.php">
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Receive</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-dispatch.php">
      
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Dispatch</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-transfer.php">
     
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Mobile Transfer </h4></button>
                 </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-status-report.php">

                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Report </h4></button>
                
         </a>
        </div><!-- /.col-* -->
    </div><!-- /.row -->

    <div class="row" style="margin-left: 10%; margin-right: 10%;">
        <div class="p50 mb30 center col-sm-3"><a href="fg-store-edit.php">
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Edit FG Store</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="employee_end-edit.php">
      
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Edit Emp End</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="head-office-edit.php">
     
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Edit Head Office</h4></button>
                 </a>
        </div><!-- /.col-* -->

     <!--   <div class="p50 mb30 center col-sm-3"><a href="admin-home.php">

                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Main</h4></button>
                
         </a>
        </div> --> <!-- /.col-* -->
    </div><!-- /.row -->

<div class="col-md-3"> </div>                                            
<div class="col-md-6">
    <div class="background-white p20 mb50">
        <h2 class="page-title">Mobile Receive</h2>

        <form method="post" action="generate-reference.php">

      

<?php
        include 'dbConnector.php';

        ///get max referenceid
        $sql_query = "SELECT max(ID) as MAXID FROM generatereference ORDER BY ID ;" ;
        $result = $db->query($sql_query) or die( "reference query failed");
        $row = mysqli_fetch_array($result);
        if($db->query($sql_query) == TRUE){
            //echo "CREATE DATABASE SUCCESSFULLY";
            $ID = $row['MAXID'];
        }
        else{
            echo"ERROR:".mysqli_error($db);
        } 

///get the last referenceid from generatereference table 
        $sql_query = "SELECT REFERENCEID FROM generatereference WHERE ID = '$ID' ;"; 
        $result = $db->query($sql_query) or die( "brand query failed");
        $row = mysqli_fetch_array($result);
        if($db->query($sql_query) == TRUE){
            //echo "CREATE DATABASE SUCCESSFULLY";
            $LASTREFERENCEID = $row['REFERENCEID'];
            //echo $row['REFERENCEID'];
        }
        else{
            echo"ERROR:".mysqli_error($db);
        } 


///generate final reference id
        $str1 = "REF";
        $str2 = "MR";
        $year = date("Y");
        $month = date("m");
        $reference = $str1.sprintf("-").$str2.sprintf("-").$year.sprintf("-").$month.sprintf("-").$LASTREFERENCEID ;

?>


            <div class="form-group">
                <label for="REFERENCE">Reference <span class="required"></span></label>
              <!--  <input type="text" class="form-control" name="reference" id="reference" style="width:50%;" placeholder="Reference" readonly>
                 <button type="submit" class="btn btn-primary" name="NewReference">New</button> -->
                 <table class="table-responsive">
                      <thead>
                    <tr>
                     
                    </tr>
                    <tbody>
                    <tr>
                      <td><input type="text" class="form-control" name="reference" id="reference" placeholder="Reference" value="<?php echo "$reference"; ?>" readonly></td>
                      <td> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp </td>
                      <td>
                        <button type="" class="btn btn-primary" name="NewReference" > New</button>
                       <!-- <button type="" class="btn btn-primary" name="NewReference" > 
                        <a href="generate-reference.php" >New</a></button> -->
                    </td>
                    </tr>
                    </tbody>
                </thead>
                 </table>
            </div>
        </form>


        <form method="post" name="receiveform" action="admin-mobile-receive-in.php" > 
            <div class="form-group">
                <label>Brand <span class="required"></span></label>
                <select class="form-control" name='brand' id='brand' required="">
                <?php
                    $sql_query = mysqli_query($db,"select * from mobile_brand order by BRAND");
                        while($row = mysqli_fetch_array($sql_query)){
                            echo "<option value='".$row['BRAND']."'>".$row['BRAND']."</option>";
                        }
                ?>
                </select>
            </div>   

                    <div class="form-group">
                        <label for="exampleInputPassword1">Model <span class="required"></span></label>
                        <input type="text" class="form-control" name="model" id="model" placeholder="Model" required="">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputURL1">Batch <span class="required"></span></label>
                        <input type="text" class="form-control" name="batch" id="batch" placeholder="Batch" required="">
                    </div>
                    

                    <div class="form-group">
                        <label for="exampleInputURL1">QR code/ IMEI <span class="required"></span></label>
                        <input type="text" class="form-control" name="qr_code" id="qr_code" placeholder="13-15 Digit IMEI" required="">
                    </div>

                <!--   <div class="form-group">
                        <label for="">Date <span class="required"></span></label>
                        <input type="date" class="form-control" name="receiveDate" id="receiveDate" placeholder="Date" required="">
                    </div> --> <!-- /.form-group -->

<?php
    date_default_timezone_set("Asia/Dhaka");
?>
                    
                     <div class="form-group">
                        <label for="">Date <span class="required"></span></label>

                        <input type="DATE" class="form-control" name="receiveDate" id="receiveDate" placeholder="Date" value="" required >
                    </div><!-- /.form-group -->

                 
            
            <button type="submit" class="btn btn-primary" name="AddStock" onClick="confSubmit(this.form);">ADD</button> 
        </form>
        </div> <!-- /.background-white p20 mb50 -->
    </div> <!-- /.col-md-6 -->
</div> <!-- /.col-sm-12 -->

                                    </div> <!-- /.row -->
                                </div><!-- /.container-fluid -->
                            </div><!-- /.content-admin-main-inner -->
                        </div><!-- /.content-admin-main -->

                        <div class="content-admin-footer">
                            <div class="container-fluid">
                                <div class="content-admin-footer-inner">
                                    <h5 style="text-align:center;">&copy; 2019 All rights are reserved.</h5>
                                </div><!-- /.content-admin-footer-inner -->
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-footer  -->
                    </div><!-- /.content-admin-wrapper -->
                </div><!-- /.content-admin -->
            </div><!-- /.wrapper-admin -->
        </div><!-- /.outer-admin -->
    </div><!-- /.main -->
</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

</body>
</html>
