<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

    <title>Mobile Management System - Admin Dashboard</title>
</head>


<body class="">
    
<div class="page-wrapper">
    
    <header class="header header-minimal">
    <div class="header-wrapper"> <div class="header-logo">
                    <a href="admin-dashboard.html">
                        <img src="assets/img/logo1.png" alt="Logo">
                    </a>
                </div><!-- /.header-logo -->
        <div class="container-fluid">
            <div class="header-inner">
                

                <div class="header-content">
                    <div class="header-bottom">
 


                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->

</header><!-- /.header -->




    <div class="main">
        <div class="outer-admin">
            <div class="wrapper-admin">
                        <div class="sidebar-secondary-admin">
                    <ul>
                        <li class="active">
                            <a href="admin-dashboard-home.php">
                                <span ></span>
                                <span class="title">Mobile Management System</span>
                            <!--    <span class="subtitle">Add Received Mobiles</span> -->
                            </a>
                        </li>

                    </ul>
                </div><!-- /.sidebar-secondary-admin -->
                
                <div class="content-admin">
                    <div class="content-admin-wrapper">
                        <div class="content-admin-main">
                            <div class="content-admin-main-inner">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-12">
   
    <div class="page-title">
        <?php  if (isset($_SESSION['username'])) : ?>
			<p style="float:right;"> <a href="login.php" style="color: red;"> logout</a> </p>
            <p style="float:right;">Welcome Mr/Mrs <strong><?php echo $_SESSION['username']; ?> </strong></p> 
		<?php endif ?>
    </div>
</div>

                                    </div>
                                </div><!-- /.container-fluid -->
                            </div><!-- /.content-admin-main-inner -->
                        </div><!-- /.content-admin-main -->

                        <div class="content-admin-footer">
                            <div class="container-fluid">
                                <div class="content-admin-footer-inner">
                                    &copy; 2019 All rights are reserved.
                                </div><!-- /.content-admin-footer-inner -->
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-footer  -->
                    </div><!-- /.content-admin-wrapper -->
                </div><!-- /.content-admin -->
            </div><!-- /.wrapper-admin -->
        </div><!-- /.outer-admin -->
    </div><!-- /.main -->
</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

</body>
</html>
