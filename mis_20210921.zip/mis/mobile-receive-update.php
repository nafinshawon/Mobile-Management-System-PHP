<?php
                    //include database configuration file
        include 'dbConnector.php';


        $sql_query = "SELECT max(RECEIVEID) as MAXRECEIVEID FROM mobile_receive ORDER BY RECEIVEID ;" ;
        $result = $db->query($sql_query) or die( "maxreceiveid query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){
        	//echo "CREATE DATABASE SUCCESSFULLY";
        	$MAXRECEIVEID = $row['MAXRECEIVEID'];
    	}
    	else{
        	echo"ERROR:".mysqli_error($db);
    	} 
 
    	$sql_query = "SELECT BRAND, RECEIVEID FROM mobile_receive WHERE RECEIVEID = '$MAXRECEIVEID' ;"; 
        $result = $db->query($sql_query) or die( "receiveid query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){
        	//echo "CREATE DATABASE SUCCESSFULLY";
        	$BRANDNAME = $row['BRAND'];
        	//echo $row['BRAND'];
    	}
    	else{
        	echo"ERROR:".mysqli_error($db);
    	} 


    	$sql_query = "SELECT BRANDID, BRAND FROM mobile_brand WHERE BRAND = '$BRANDNAME' ;" ;
        $result = $db->query($sql_query) or die( "brand query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){
        	//echo "CREATE DATABASE SUCCESSFULLY";
        	$BRANDID = $row['BRANDID'];
        	//echo $row['BRANDID'];
    	}
    	else{
        	echo"ERROR:".mysqli_error($db);
    	} 


    	$sql_query = "SELECT * FROM mobile_receive";
		//$result = mysqli_query($db, $sql_query);
		$result = $db->query($sql_query);
		$count = $result->num_rows;
		//$RECEIVEID = $count+0;

         
        $sql_query = "UPDATE mobile_receive
						SET BRANDID = '$BRANDID'
	 					WHERE RECEIVEID = '$MAXRECEIVEID' ;";
		$result = $db->query($sql_query) or die( "query failed");
                                        

?>