<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

    <title>Log In</title>
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header">
    <div class="header-wrapper">
        <div class="container">
            <div class="header-inner">
                <div class="header-logo">
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                       
                    </a>
                </div><!-- /.header-logo -->

                <div class="header-content">

                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->
</header><!-- /.header -->


    <div class="main">
        <div class="main-inner">
            <div class="container">
                <div class="content">

                    <div class="row">
                      <!--  <span><h1 style="text-align:center;">Mobile Management System</h1></span> -->
    <div class="col-sm-4 col-sm-offset-4">
        <div class="page-title">
            <h1>Login</h1>
        </div><!-- /.page-title -->

        <form method="post" action="login.php">
            <?php include('errors.php'); ?>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" id="username">
            </div><!-- /.form-group -->
            <div class="form-group" style="display:none;">
                <label for="role">Role</label>
                        <select class="form-control" title="Select Option" name="role" id="role">
                            <option>General</option>
                          <!--  <option>Admin</option> -->
                        </select>
            </div><!-- /.form-group -->

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" id="password">
            </div><!-- /.form-group -->

            <button type="submit" class="btn btn-primary pull-right" name="login_user">Login</button>
        </form>
    </div><!-- /.col-sm-4 -->
</div><!-- /.row -->

                </div><!-- /.content -->
            </div><!-- /.container -->
        </div><!-- /.main-inner -->
    </div><!-- /.main -->



</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

</body>

</html>
