<?php
include "dbConnector.php";

//$connect = mysqli_connect("localhost", "skfmis_skfadmin", "skfstock@2019!", "skfmis_stockmanagedb");
$request = mysqli_real_escape_string($db, $_POST["query"]);
$query = "SELECT DISTINCT EMPID, EMPNAME FROM mobile_dispatch WHERE ASSIGNSTATUS = '1' AND EMPID LIKE '%".$request."%' OR EMPNAME LIKE '%".$request."%' ";

$result = mysqli_query($db, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
  $data[] = $row["EMPID"]." - ".$row["EMPNAME"];
 }
 echo json_encode($data);
}

?>