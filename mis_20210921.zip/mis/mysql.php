<?php

include "dbConnector.php";
$request = mysqli_real_escape_string($db, $_POST["query"]);
$query = "SELECT DISTINCT EMPID, FFNAME FROM employee WHERE EMPID LIKE '%".$request."%' OR FFNAME LIKE '%".$request."%' AND STATUS = '1'  ";

$result = mysqli_query($db, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
 // $data[] = $row["EMPID"];
 // $data[] = $row["FFNAME"];
  $data[] = $row["EMPID"]." - ".$row["FFNAME"];
 }
 echo json_encode($data);
}

?>