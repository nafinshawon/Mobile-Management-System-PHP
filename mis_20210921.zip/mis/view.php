<?php
require("dbConnector.php");
$id =$_REQUEST['RECEIVEID'];

$query ="SELECT * FROM mobile_receive WHERE RECEIVEID  = '$id'";
$result = $db->query($query) or die( "bookid query failed");           
$test = $result->fetch_assoc();
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$RECEIVEID=$test['RECEIVEID'] ;
				$BRAND= $test['BRAND'] ;					
				$MODEL=$test['MODEL'] ;
				$BATCH=$test['BATCH'] ;
				$QRCODE=$test['QRCODE'] ;
				$RECEIVEDATE=$test['RECEIVEDATE'];
				$LOCATIONNAME=$test['LOCATIONNAME'];

if(isset($_POST['save']))
{	
	//$RECEIVEID_save = $_POST['RECEIVEID'];
	$BRAND_save = $_POST['BRAND'];
	$MODEL_save = $_POST['MODEL'];
	$BATCH_save = $_POST['BATCH'];
	$QRCODE_save = $_POST['QRCODE'];
	$RECEIVEDATE_save = $_POST['RECEIVEDATE'];
	$LOCATIONNAME_save = $_POST['LOCATIONNAME'];

$query ="UPDATE mobile_receive 
			SET  BRAND ='$BRAND_save',
		 			MODEL ='$MODEL_save', 
		 			BATCH ='$BATCH_save', 
		 			QRCODE ='$QRCODE',
		 			RECEIVEDATE ='$RECEIVEDATE_save', 
		 			LOCATIONNAME ='$LOCATIONNAME_save'
		 			 WHERE RECEIVEID = '$id'";
$result = $db->query($query) or die( "update query failed");

//	echo "Saved!";
//	include "fg-store-edit.php";
//	header("Location: fg-store-edit.php");			
}
//mysql_close($db);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
<title>Mobile Management System - Edit Received Item</title>
</head>

<body>
<form method="post">
<table>
    <tr>
		<td>RECEIVEID</td>
		<td><input type="text" name="RECEIVEID" value="<?php echo $RECEIVEID ?>" readonly/></td>
	</tr> 
	<tr>
		<td>BRAND</td>
		<td><input type="text" name="BRAND" value="<?php echo $BRAND ?>"/></td>
	</tr>
	<tr>
		<td>MODEL</td>
		<td><input type="text" name="MODEL" value="<?php echo $MODEL ?>"/></td>
	</tr>
	<tr>
		<td>BATCH</td>
		<td><input type="text" name="BATCH" value="<?php echo $BATCH ?>"/></td>
	</tr>
	<tr>
		<td>QRCODE</td>
		<td><input type="text" name="QRCODE" value="<?php echo $QRCODE ?>" readonly/></td>
	</tr>
	<tr>
		<td>RECEIVEDATE</td>
		<td><input type="text" name="RECEIVEDATE" value="<?php echo $RECEIVEDATE ?>"/></td>
	</tr>
	<tr>
		<td>LOCATIONNAME</td>
		<td><input type="text" name="LOCATIONNAME" value="<?php echo $LOCATIONNAME ?>" readonly/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>

</body>
</html>
