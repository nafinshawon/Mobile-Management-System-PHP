<?php include "dbConnector.php";  ?>

<?php 

			if(isset($_REQUEST['LoadStock'])){
    			$qrcode = $_POST['qr_code'];
                //$qr_code = (isset($_POST['qr_code']) ? $_POST['qr_code'] : '');
               

				$sql = "SELECT RECEIVEID,BRAND,MODEL,BATCH,REFERENCE,QRCODE,RECEIVEDATE 
							FROM mobile_receive 
							WHERE QRCODE = '$qrcode' ;";
	
				$result = $db->query($sql) or die( "query failed");

				$row = mysqli_fetch_array($result);


    			if($db->query($sql)==TRUE)
    			{
       				// echo "CREATE DATABASE SUCCESSFULLY";
        			$RECEIVEID = $row['RECEIVEID'] ;
       				// echo $row['RECEIVEID'] ;

    			}
   				 else
    			{
        				echo"ERROR:".mysqli_error($db);
    			} 


				$sql = "SELECT * FROM mobile_dispatch";
				$result=$db->query($sql);
				$count=$result->num_rows;
				
				/////////////////////get LAST DISPATCHID to insert new DISPATCHID//////////////////
                ///get max DISPATCHID
                $sql_query = "SELECT max(DISPATCHID) as MAXDISPATCHID FROM mobile_dispatch ORDER BY DISPATCHID ;" ;
                $result = $db->query($sql_query) or die( "DISPATCH ID query failed");
                $row = mysqli_fetch_array($result);
                if($db->query($sql_query) == TRUE){
                    //echo "CREATE DATABASE SUCCESSFULLY";
                    $MAXDISPATCHID = $row['MAXDISPATCHID'];
                }
                else{
                    echo"DISPATCH ID ERROR:".mysqli_error($db);
                } 

                ///get the last DISPATCHid from mobile_dispatch table 
                $sql_query = "SELECT DISPATCHID FROM mobile_dispatch WHERE DISPATCHID = '$MAXDISPATCHID' ;"; 
                $result = $db->query($sql_query) or die( "Max DISPATCH ID query failed");
                $row = mysqli_fetch_array($result);
                if($db->query($sql_query) == TRUE){
                    //echo "CREATE DATABASE SUCCESSFULLY";
                    $LASTDISPATCHID = $row['DISPATCHID'];
                    //  echo $row['DISPATCHID'];
                }
                else{
                    //echo"ERROR:".mysqli_error($db);
                } 
                $DISPATCHID = $LASTDISPATCHID + 1;
                /////////////////////END of LAST DISPATCHID/////////////////// 
				
			//	$DISPATCHID=$count+1;

				//echo "$name";

				$sql = "INSERT INTO mobile_dispatch (DISPATCHID, RECEIVEID) 
					VALUES ($DISPATCHID, '$RECEIVEID');" ;    
		

				if($db->query($sql)==TRUE)
				{
					//echo "CREATE SUCCESSFULLY";

				}
				else
				{
					echo"ERROR:".mysqli_error($db);
					$message = "OOPS..Request Creation Failed. Try Again";
					echo "<script type='text/javascript'>alert('$message');</script>";
				} 



  			}else { //echo"ERROR new:".mysqli_error($db);
?>
    			
    	<?php } ?>


