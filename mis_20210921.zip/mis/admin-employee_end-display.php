<?php
include "dbConnector.php";
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

    <title>Mobile Management System - Status Report</title>
    
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
    function hideURLbar(){ window.scrollTo(0,1); } </script>
    <style>
        .my-custom-scrollbar {
            position: relative;
            height: 200px;
            overflow: auto;
        }
        .table-wrapper-scroll-y {
            display: block;
        }
        h4{
            color:white;
        }
        .button-but2 {
            background-color: #CC3300;  /* Green */
           /* background-color:#009f8b; */
            width:80%;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 50px;
            
            margin-bottom: 25px;
           /* margin: 4px 6px; */
            cursor: pointer;
            -webkit-transition-duration: 0.4s; /* Safari */
            transition-duration: 0.4s;
        }
        
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
        }
        .button2:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        .button3 {
                border-radius: 12px;
        }
        .boxcolor{
            background-color:#000099;
        }
        .button-but3 {
            background-color: #7B0404;  
            width:90%;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 50px;
            margin-bottom: 25px;
            cursor: pointer;
            -webkit-transition-duration: 0.4s; /* Safari */
            transition-duration: 0.4s;
        }
        .button4{
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.40),0 17px 50px 0 rgba(0,0,0,0.25);
        }
    </style> 
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header header-minimal">
    <div class="header-wrapper">
        <div class="container-fluid">
            <div class="header-inner">
                <div class="header-content">
                    <div class="header-bottom">

                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->

</header><!-- /.header -->




    <div class="main">
        <div class="outer-admin">
            <div class="wrapper-admin">

                <div class="content-admin">
                    <div class="content-admin-wrapper">
                        <div class="content-admin-main">
                            <div class="content-admin-main-inner">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            
   <!-- <div class="page-title">
        <h1>Report</h1>
    </div>-->
     <div class="header-logo">
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                    </a>
                </div><!-- /.header-logo -->                                       
    <div class="page-title">
        <?php  if (isset($_SESSION['username'])) : ?>
			<p style="float:right;"> <a href="login.php" style="color: red;"> logout</a> </p>
            <p style="float:right;">Welcome Mr/Mrs <strong><?php echo $_SESSION['username']; ?> </strong></p> 
		<?php endif ?>
    </div>
                                            
    <div class="row" style="margin-left: 10%; margin-right: 10%;">
        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-receive.php">
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Receive</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-dispatch.php">
      
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Dispatch</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-mobile-transfer.php">
     
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Mobile Transfer </h4></button>
                 </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="admin-status-report.php">

                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Report </h4></button>
                
         </a>
        </div><!-- /.col-* -->
    </div><!-- /.row -->

    <div class="row" style="margin-left: 10%; margin-right: 10%;">
        <div class="p50 mb30 center col-sm-3"><a href="fg-store-edit.php">
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Edit FG Store</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="employee_end-edit.php">
      
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Edit Emp End</h4></button>
           </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="head-office-edit.php">
     
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Edit Head Office</h4></button>
                 </a>
        </div><!-- /.col-* -->

     <!--   <div class="p50 mb30 center col-sm-3"><a href="admin-home.php">

                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Main</h4></button>
                
         </a>
        </div> --> <!-- /.col-* -->
    </div><!-- /.row -->


    <div class="background-white p20 mb50">
        <h2 class="page-title">Status Report </h2>
        
        <?php
                /////////////////////// FG QUANTITY COUNT //////////////////////
                $query ="SELECT count(QUANTITY) AS QTY 
                        FROM mobile_receive  
                        WHERE QUANTITY = '1' AND LOCATIONNAME = 'FG Store' ; ";
                $result = $db->query($query) or die( "FG QTY query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $FGQUANTITY = $row['QTY'];
                        }
                }
                /////////////////////// END OF FG QUANTITY COUNT //////////////////////

                /////////////////////// DAMAGE QUANTITY COUNT //////////////////////
                $query ="SELECT COUNT(TRANSFERID) AS DQTY
                            FROM mobile_transfer
                            WHERE TRANSFERTO = 'Damage' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "DAMAGE DQTY query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $DAMAGEQUANTITY = $row['DQTY'];
                        }
                }
                /////////////////////// END OF DAMAGE QUANTITY COUNT //////////////////////

                ////////////////////// BRANCH QUANTITY COUNT ///////////////////
                $query ="SELECT COUNT(TRANSFERID) AS QTY1
                            FROM mobile_transfer
                            WHERE TRANSFERTO = 'Branch' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "QTY1 query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $BRANCHQUANTITY1 = $row['QTY1'];
                        }
                }

                $query ="SELECT COUNT(DISPATCHID) AS QTY2
                            FROM mobile_dispatch
                            WHERE LOCATION = 'Branch' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "QTY2 query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $BRANCHQUANTITY2 = $row['QTY2'];
                        }
                }
                ////////////////////// END OF BRANCH QUANTITY COUNT ///////////////////

                /////////////////////// EMP END QUANTITY COUNT //////////////////////
                $query ="SELECT COUNT(DISPATCHID) AS EQTY
                            FROM mobile_dispatch
                            WHERE LOCATION = 'Employee End' AND ASSIGNSTATUS = '1' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "Employee End EQTY query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $EMPENDQUANTITY = $row['EQTY'];
                        }
                }
                /////////////////////// END OF EMP END QUANTITY COUNT //////////////////////

                /////////////////////// HEAD OFFICE QUANTITY COUNT //////////////////////
                $query ="SELECT COUNT(DISPATCHID) AS HOQTY
                            FROM mobile_dispatch
                            WHERE LOCATION = 'Head Office' AND STATUS = '5' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "HEAD OFFICE HOQTY query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $HOQUANTITY = $row['HOQTY'];
                        }
                }
                /////////////////////// END OF HEAD OFFICE QUANTITY COUNT //////////////////////

                /////////////////////// LOST QUANTITY COUNT //////////////////////
                $query ="SELECT COUNT(TRANSFERID) AS LQTY
                            FROM mobile_transfer
                            WHERE TRANSFERTO = 'Lost' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "LOST LQTY query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $LOSTQUANTITY = $row['LQTY'];
                        }
                }
                /////////////////////// END OF LOST QUANTITY COUNT //////////////////////
                
                /////////////////////// MATURE QUANTITY COUNT //////////////////////
                $query ="SELECT COUNT(TRANSFERID) AS MQTY
                            FROM mobile_transfer
                            WHERE TRANSFERTO = 'Mature' AND RECEIVEID<>0; ";
                $result = $db->query($query) or die( "LOST MQTY query failed");           
                if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                            $MATUREQUANTITY = $row['MQTY'];
                        }
                }
                /////////////////////// END OF MATURE QUANTITY COUNT //////////////////////
                   
            ?>

        <div class="row">
        <div class="col-sm-2"><a href="admin-fg-store-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>FG Store </h4>
                <h4><?php echo "(";
                        echo "$FGQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->

        <div class="col-sm-2"><a href="admin-damage-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>Damage </h4>
                <h4><?php echo "(";
                        echo "$DAMAGEQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->

        <div class="col-sm-2"><a href="admin-branch-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>Branch </h4>
                 <h4><?php echo "(";
                        $BRANCHQUANTITY = $BRANCHQUANTITY1+$BRANCHQUANTITY2;
                        echo "$BRANCHQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->

        <div class="col-sm-2"><a href="admin-employee_end-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>Employee End </h4>
                 <h4><?php echo "(";
                        echo "$EMPENDQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->

        <div class="col-sm-2"><a href="admin-head-office-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>Head Office </h4>
                <h4><?php echo "(";
                        echo "$HOQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->

        <div class="col-sm-2"><a href="admin-lost-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>Lost </h4>
                <h4><?php echo "(";
                        echo "$LOSTQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->
        
        <div class="col-sm-2"><a href="mature-display.php">
            <button class="button-but3 button1 button4 button3 btn btn-primary " >
                <h4>Mature </h4>
                <h4><?php echo "(";
                        echo "$MATUREQUANTITY";
                        echo ")"; ?> </h4>
            </a>
        </div><!-- /.col-* -->
    </div><!-- /.row -->
        
        
 <div class="panel panel-default">
        <div class="panel-heading">
            Employee End
            <a href="employee_end.php" class="btn btn-success pull-right">Export Data</a>
            <button class="btn pull-right ">QUANTITY  <?php echo ": "; echo "$EMPENDQUANTITY"; ?></button>
            <div class="col-sm-3" style="float: right;">
                    <input class="form-control" id="myInput" type="text" placeholder="Search..">
            </div>
        </div>
        <div class="panel-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                      <th>SL</th>
                      <th>BRAND</th>
                      <th>MODEL</th>
                      <th>QR/ IMEI</th>
                      <th>TERRITORY</th>
                      <th>EMP ID</th>
                      <th>EMP NAME</th>
                      <th>LOCATION</th>
                      <th>ASSIGN DATE</th>
                      <th>DURATION</th>
                    </tr>
                </thead>
                <tbody id="myTable">
                <?php
                   // include database configuration file
                    include "dbConnector.php";

                    //get system date
                    $date1= date("Y/m/d");
                    $sysDate1 = explode('/', $date1);
                    $date1year = trim($sysDate1[0]);
                    $date1month = trim($sysDate1[1]);
                    $date1day = trim($sysDate1[2]);
                    // end of system date

                    //get records from database
                    
                    $id=1;
                    $query ="SELECT p.RECEIVEID, p.BRAND, p.MODEL, p.BATCH, p.REFERENCE, p.QRCODE, p.RECEIVEDATE, 
                                                re.TERRITORY, re.EMPID, re.EMPNAME, re.LOCATION, re.DISPATCHID, re.ASSIGNDATE, re.RECEIVEID
                                        FROM mobile_receive p 
                                        LEFT JOIN mobile_dispatch re ON re.RECEIVEID = p.RECEIVEID
                                        WHERE LOCATION = 'Employee End' AND p.LOCATIONID = '1' AND re.STATUS = '4' AND re.ASSIGNSTATUS = '1' ; ";
                   

                    $result = $db->query($query) or die( "2ND query failed");
                    
                    if($result->num_rows>0){ 
                        while($row = $result->fetch_assoc()){ 
                                //get ASSIGN date from database
                            $ASSIGNDATE = $row['ASSIGNDATE'];
                            $mobileassignDate2 = explode('-', $ASSIGNDATE);
                            $date2year = trim($mobileassignDate2[0]);
                            $date2month = trim($mobileassignDate2[1]);
                            $date2day = trim($mobileassignDate2[2]);
                            //end of get ASSIGN date from database

                            //find duration
                         
                            if($date1year <= $date2year){
                                $year = $date1year-$date2year;
                                $month = $date1month-$date2month;
                                $day = $date1day-$date2day;
                            }
                            elseif($date1year > $date2year){
                                
                                //$month = $date1month-$date2month;

                                if($date2month == '12'){
                                    $year = $date1year-$date2year-1;
                                    $month = $date1month;
                                }
                                elseif($date1month < $date2month){
                                    $year = $date1year-$date2year-1;
                                    $month = $date1month+('12'-$date2month);
                                }
                                else{
                                   // $month = $date1month;
                                   $year = $date1year-$date2year;
                                   $month = $date1month-$date2month;
                                }
                                $day = $date1day-$date2day;
                            }
                            else{
                                $year = $date1year-$date2year-1;
                                $day = $date1day-$date2day+1;
                                
                                if($date1month == $date2month){
                                    $month = $date1month-$date2month+1;
                                }
                                else{
                                    $month = $date1month;
                                }
                            } 
                            
                           // $year = $date1year-$date2year;
                           // $month = $date1month-$date2month;
                           // $day = $date1day-$date2day;
                            //end of find duration

                            ?>                
                    <tr>
                        <td><?php echo $id; ?></td>
                        <td><?php echo $row['BRAND']; ?></td>
                        <td><?php echo $row['MODEL']; ?></td>
                        <td><?php echo $row['QRCODE']; ?></td>
                        <td><?php echo $row['TERRITORY']; ?></td>
                        <td><?php echo $row['EMPID']; ?></td>
                        <td><?php echo $row['EMPNAME']; ?></td> 
                        <td><?php echo $row['LOCATION']; ?></td>
                        <td><?php echo $row['ASSIGNDATE']; ?></td>
                        <td><?php echo "$year"."Y "."$month"."M "."$day"."D " ; ?></td>
                    </tr> 
                    
                    <?php $id = $id+1; } }else{ ?>
                    <tr><td colspan="5">No information found.....</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>   
    </div>
</div>

                                    </div>
                                </div><!-- /.container-fluid -->
                            </div><!-- /.content-admin-main-inner -->
                        </div><!-- /.content-admin-main -->

                        <div class="content-admin-footer">
                            <div class="container-fluid">
                                <div class="content-admin-footer-inner">
                                    <h5 style="text-align:center;">&copy; 2019 All rights are reserved.</h5>
                                </div><!-- /.content-admin-footer-inner -->
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-footer  -->
                    </div><!-- /.content-admin-wrapper -->
                </div><!-- /.content-admin -->
            </div><!-- /.wrapper-admin -->
        </div><!-- /.outer-admin -->
    </div><!-- /.main -->
</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

<!-- ////search////////-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
</body>
</html>
