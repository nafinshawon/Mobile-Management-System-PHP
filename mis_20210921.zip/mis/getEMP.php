<?php
include "dbConnector.php";

//$connect = mysqli_connect("localhost", "skfmis_skfadmin", "skfstock@2019!", "skfmis_stockmanagedb");

//$request = mysqli_real_escape_string($connect, $_POST["query"]);
//$transferEMPID = $_POST["territory"];
$selectedTerritory = isset($_POST['territory']) ? $_POST['territory'] : '';

$query = "SELECT  EMPID, FFNAME, TRCODE FROM employee WHERE TRCODE = '" . $selectedTerritory . "'  ";

$result = mysqli_query($db, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
  while($row = mysqli_fetch_assoc($result))
  {
 //  // $data[] = $row["BRAND"];
 //  // $data[] = $row["MODEL"];
  $data[] = $row["EMPID"]."-".$row["FFNAME"] ;
 //  $data [] = $row;
  }

 //$data = mysqli_fetch_assoc($result);
 echo json_encode($data);
}
else echo false;

?>