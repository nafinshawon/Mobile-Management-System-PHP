<?php
                    //include database configuration file
        include 'dbConnector.php';

///get max receiveid
        $sql_query = "SELECT max(RECEIVEID) as MAXRECEIVEID FROM mobile_receive ORDER BY RECEIVEID ;" ;
        $result = $db->query($sql_query) or die( "brand query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){
        	//echo "CREATE DATABASE SUCCESSFULLY";
        	$MAXRECEIVEID = $row['MAXRECEIVEID'];
            //echo "$MAXRECEIVEID";
    	}
    	else{
        	echo"ERROR:".mysqli_error($db);
    	} 



///get the last entry from receive table 
    	$sql_query = "SELECT ENTRY FROM mobile_receive WHERE RECEIVEID = '$MAXRECEIVEID' ;"; 
        $result = $db->query($sql_query) or die( "brand query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){

            if($MAXRECEIVEID < '1'){
                $LASTENTRY = '1000';
                $NEWENTRY = $LASTENTRY + 1;
            }

            else{

        	   //echo "CREATE DATABASE SUCCESSFULLY";
        	   $LASTENTRY = $row['ENTRY'];
        	   //echo $row['ENTRY'];
                $NEWENTRY = $LASTENTRY + 1;
                // echo "     ";
                // echo "$NEWENTRY";
            }

    	}
    	else{
        	echo"ERROR:".mysqli_error($db);
    	} 


////Insert new reference id in generate reference table
        $sql_query = "SELECT * FROM generatereference";
        $result = $db->query($sql_query);
        $count = $result->num_rows;
        $ID = $count+1;

        $sql_query = "INSERT INTO generatereference 
        (ID, REFERENCEID) 
        VALUES 
        ($ID, '$NEWENTRY');" ;

        if($db->query($sql_query)==TRUE){
                    
            $message = "Reference Generated Successfully";
            echo "<script>alert('$message');</script>";
            include "mobile-receive.php";
            //echo "<script type='text/javascript'>location.href = mobile-receive.php';</script>";
        
        }else
        {
            //echo"ERROR:".mysqli_error($db);
            $message = "New Reference Already Exist";
            echo "<script type='text/javascript'>alert('$message');</script>";
            include "mobile-receive.php";
            //echo "<script type='text/javascript'>location.href = mobile-receive.php';</script>";
        }

                                        

?>