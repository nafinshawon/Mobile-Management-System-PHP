<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">

    <title>Mobile Management System</title>
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header">
    <div class="header-wrapper">
        <div class="container">
            <div class="header-inner">
                <div class="header-logo">
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                        <span>Stock Management System</span>
                    </a>
                </div><!-- /.header-logo -->

                <div class="header-content">
                    <div class="header-top">
                <!--    <div class="header-search">
                            <input type="text" class="form-control" placeholder="Search for...">
                        </div>-->
                        <!-- /.header-search -->

                        <ul class="header-nav-secondary nav nav-pills">
                            <li><a href="login.php">Login</a></li>
                            <li><a href="register.php">Register</a></li>
                        </ul>
                    </div><!-- /.header-top -->

                    <div class="header-bottom">

                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->
</header><!-- /.header -->




    <div class="main">
        <div class="main-inner">
            <div class="container">
                <div class="content">
                    


                    <div class="row">
    <div class="col-sm-4 col-sm-offset-4">
        <div class="page-title">
            <h1>Register</h1>
        </div><!-- /.page-title -->

        <form method="post" action="register.php">
            <?php include('errors.php'); ?>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" id="username">
            </div><!-- /.form-group -->

            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" class="form-control" name="email" id="email">
            </div><!-- /.form-group -->
            
            <div class="form-group">
                <label for="role">Role</label>
                        <select class="form-control" title="Select Option" name="role">
                            <option>General</option>
                            <option>User</option>
                            <option>Admin</option>
                        </select>
            </div><!-- /.form-group -->

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password_1" id="password_1">
            </div><!-- /.form-group -->

            <div class="form-group">
                <label for="confirm-password">Confirm password</label>
                <input type="password" class="form-control" name="password_2" id="password_2">
            </div><!-- /.form-group -->

            <button type="submit" class="btn btn-primary pull-right" name="reg_user">Register</button>
        </form>
    </div><!-- /.col-sm-4 -->
</div><!-- /.row -->

                </div><!-- /.content -->
            </div><!-- /.container -->
        </div><!-- /.main-inner -->
    </div><!-- /.main -->

    <footer class="footer">
    

    <div class="footer-bottom">
        <div class="container">
            <div class="footer-bottom-left">
                <h5 style="text-align:center;">&copy; 2019 All rights are reserved.</h5>
            </div><!-- /.footer-bottom-left -->

        </div><!-- /.container -->
    </div>
</footer><!-- /.footer -->

</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>

</body>
</html>
