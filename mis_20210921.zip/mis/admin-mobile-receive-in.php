<?php
if (!session_id() && !headers_sent()) {
   session_start();
}  
   include "dbConnector.php";

	// variable declaration
	$username = "";
	$email    = "";
	$errors = array(); 
	$_SESSION['success'] = "";

///get max referenceid
        $sql_query = "SELECT max(ID) as MAXID FROM generatereference ORDER BY ID ;" ;
        $result = $db->query($sql_query) or die( "reference query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){
        	//echo "CREATE DATABASE SUCCESSFULLY";
        	$ID = $row['MAXID'];
    	}
    	else{
        	echo"ERROR:".mysqli_error($db);
    	} 

///get the last referenceid from generatereference table 
    	$sql_query = "SELECT REFERENCEID FROM generatereference WHERE ID = '$ID' ;"; 
        $result = $db->query($sql_query) or die( "referenceid query failed");
        $row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){
        	//echo "CREATE DATABASE SUCCESSFULLY";
        	$LASTREFERENCEID = $row['REFERENCEID'];
        	//echo $row['REFERENCEID'];
    	}
    	else{
        	//echo"ERROR:".mysqli_error($db);
    	} 


///generate final reference id
    	$str1 = "REF";
    	$str2 = "MR";
    	$year = date("Y");
    	$month = date("m");
    	$reference = $str1.sprintf("-").$str2.sprintf("-").$year.sprintf("-").$month.sprintf("-").$LASTREFERENCEID ;



if (isset($_POST['AddStock'])) {

	// stock receive form input
	$brand = $_POST["brand"];
	$model = $_POST["model"];
	$batch = $_POST["batch"];
	//$reference = $_POST["reference"];
	$qr_code = $_POST["qr_code"];
	$receiveDate = $_POST["receiveDate"];


	$sql_query = "SELECT * FROM mobile_receive";
	//$result = mysqli_query($db, $sql_query);
	$result=$db->query($sql_query);
	
	/////////////////////get LAST RECEIVEID to insert new RECEIVEID//////////////////
///get max receiveid
        $sql_query = "SELECT max(RECEIVEID) as MAXRECEIVEID FROM mobile_receive ORDER BY RECEIVEID ;" ;
        $result = $db->query($sql_query) or die( "receive ID query failed");
        $row = mysqli_fetch_array($result);
        if($db->query($sql_query) == TRUE){
            //echo "CREATE DATABASE SUCCESSFULLY";
            $MAXRECEIVEID = $row['MAXRECEIVEID'];
        }
        else{
            echo"RECEIVE ID ERROR:".mysqli_error($db);
        } 

///get the last receiveid from mobile_receive table 
        $sql_query = "SELECT RECEIVEID FROM mobile_receive WHERE RECEIVEID = '$MAXRECEIVEID' ;"; 
        $result = $db->query($sql_query) or die( "Max receive ID query failed");
        $row = mysqli_fetch_array($result);
        if($db->query($sql_query) == TRUE){
            //echo "CREATE DATABASE SUCCESSFULLY";
            $LASTRECEIVEID = $row['RECEIVEID'];
          //  echo $row['RECEIVEID'];
        }
        else{
            //echo"ERROR:".mysqli_error($db);
        } 

/////////////////////END of LAST RECEIVEID///////////////////    

	$count=$result->num_rows;
//	$RECEIVEID=$count+1;
    $RECEIVEID = $LASTRECEIVEID + 1;


	$sql_query = "INSERT INTO mobile_receive (RECEIVEID, BRANDID, BRAND, MODEL, BATCH, ENTRY, REFERENCE, QRCODE, RECEIVEDATE, QUANTITY, LOCATIONID, LOCATIONNAME) 
					VALUES ($RECEIVEID, '', '$brand', '$model', '$batch', '$LASTREFERENCEID', '$reference', '$qr_code', DATE_FORMAT('$receiveDate','%Y%m%d'), '1', '1', 'FG Store');";    
		
		      if($db->query($sql_query)==TRUE){
					
					//$message = "Mobile Received Successfully";
					//echo "<script type='text/javascript'>alert('.$message.');</script>";
					//header('location: admin-mobile-receive.php');
					include "admin-mobile-receive.php";
					//echo "<script type='text/javascript'>location.href = 'stock_receive_display.php';</script>";
                }else
                {
				//	echo"ERROR:".mysqli_error($db);
					$message = "OOPS..Request Creation Failed. Try Again";
				//	echo "<script type='text/javascript'>alert('$message');</script>";
					echo "<script type='text/javascript'>alert('.$message.');</script>";
					include "admin-mobile-receive.php";
                } 
    }

include "mobile-receive-update.php"; 

    ?>

