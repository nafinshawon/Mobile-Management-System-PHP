<?php
include 'dbConnector.php';

//get system date
                    $date1= date("Y/m/d");
                    $sysDate1 = explode('/', $date1);
                    $date1year = trim($sysDate1[0]);
                    $date1month = trim($sysDate1[1]);
                    $date1day = trim($sysDate1[2]);
                    // end of system date
                    

//get records from database
$query = $db->query("SELECT p.RECEIVEID, p.BRAND, p.MODEL, p.BATCH, p.REFERENCE, p.QRCODE, p.RECEIVEDATE,
                                                re.HOEMPNAME, re.HOEMPID, re.HODEPT, re.LOCATION, re.DISPATCHID, re.ASSIGNDATE, re.RECEIVEID
                                        FROM mobile_receive p 
                                        LEFT JOIN mobile_dispatch re ON re.RECEIVEID = p.RECEIVEID
                                        WHERE LOCATION = 'Head Office' AND p.LOCATIONID = '1' AND re.STATUS = '5' ;");

if($query->num_rows > 0){
    $delimiter = ",";
    $filename = "head-office" . date('Y-m-d') . ".csv";
    
    //create a file pointer
    $f = fopen('php://memory', 'w');
    
    //set column headers
    $fields = array( 'BRAND', 'MODEL', 'QR/ IMEI', 'EMPID', 'EMP NAME', 'DEPT', 'LOCATION', 'ASSIGN DATE', 'DURATION');
    fputcsv($f, $fields, $delimiter);
    
    //output each row of the data, format line as csv and write to file pointer
    while($row = $query->fetch_assoc()){
        //get receive date from database
                            $ASSIGNDATE = $row['ASSIGNDATE'];
                            $mobileassignDate2 = explode('-', $ASSIGNDATE);
                            $date2year = trim($mobileassignDate2[0]);
                            $date2month = trim($mobileassignDate2[1]);
                            $date2day = trim($mobileassignDate2[2]);
                            //end of get receive date from database

                            //find duration
                          
                            if($date1year <= $date2year){
                                $year = $date1year-$date2year;
                                $month = $date1month-$date2month;
                                $day = $date1day-$date2day;
                            }
                            elseif($date1year > $date2year){
                                
                                //$month = $date1month-$date2month;

                                if($date2month == '12'){
                                    $year = $date1year-$date1year;
                                    $month = $date1month;
                                }
                                 elseif($date1month < $date2month){
                                    $year = $date1year-$date2year-1;
                                    $month = $date1month+('12'-$date2month);
                                }
                                else{
                                   // $month = $date1month;
                                   $year = $date1year-$date2year;
                                   $month = $date1month-$date2month;
                                }
                                $day = $date1day-$date2day;
                            }
                            else{
                                $year = $date1year-$date2year-1;
                                $day = $date1day-$date2day+1;
                                
                                if($date1month == $date2month){
                                    $month = $date1month-$date2month+1;
                                }
                                else{
                                    $month = $date1month;
                                }
                            } 
                            //end of find duration
                            
        
        $lineData = array($row['BRAND'], $row['MODEL'], $row['QRCODE'], $row['HOEMPID'], $row['HOEMPNAME'], $row['HODEPT'], $row['LOCATION'], $row['ASSIGNDATE'], "$year"."Y "."$month"."M "."$day"."D ");  
        fputcsv($f, $lineData, $delimiter);
    }
    
    //move back to beginning of file
    fseek($f, 0);
    
    //set headers to download file rather than displayed
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '";');
    
    //output all remaining data on a file pointer
    fpassthru($f);
} else{
    echo "No Data Found.";
}
exit;

?>