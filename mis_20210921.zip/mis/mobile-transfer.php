<?php
if(!session_id() && !headers_sent()) {
   session_start();
} 

include "dbConnector.php";
?>
<?php 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>

<?php

/*if (!session_id() && !headers_sent()) {
   session_start();
}
include "dbConnector.php"; */

//session_start();
	// variable declaration
	$username = "";
	$email    = "";
	$errors = array(); 
	$_SESSION['success'] = "";


if (isset($_POST['transfer'])) {

		// transfer information input
    	$transferFrom            = $_POST["transferFrom"];
		$transferFromEmpInfo       = isset($_POST["transferFromEmpID"]) ? $_POST["transferFromEmpID"] : '';
			$transferFromEmpIDInfo = explode("-", $transferFromEmpInfo);
			$transferFromEmpID = trim($transferFromEmpIDInfo[0]); //GET EMPID FROM MERGE
			$transferFromEmpName = trim($transferFromEmpIDInfo[1]); //GET EMPNAME FROM MERGE
		$transferBrand           = $_POST["transferBrand"];
		$transferModel           = $_POST["transferModel"];
		$transfer_qr_code        = isset($_POST["transfer_IMEI"]) ? $_POST["transfer_IMEI"] : '';
		$assignedOn              = isset($_POST["assignedOn"]) ? $_POST["assignedOn"] : '';
		$transferFromBranchName  = isset($_POST["transferFromBranchName"]) ? $_POST["transferFromBranchName"] : '';
    	$concernPerson           = $_POST["concernPerson"];
    	$transferFromHOEMPID     = $_POST["transferFromHOEMPID"];
    	$transferFromHOEMPName   = $_POST["transferFromHOEMPName"];
    	$transferFromDept        = $_POST["transferFromDept"];

		$transferDate            = $_POST["transferDate"];

		$transferTo              = $_POST["transferTo"];
		$transferToTRCODE		 = $_POST["transferToTRCODE"];
		$transferToEmpIDInfo     = $_POST["transferToEmpID"];
			$transferToEmpIDInfo = explode("-", $transferToEmpIDInfo);
			$transferToEmpID = trim($transferToEmpIDInfo[0]);
			
		$transferToEmpName       = isset($_POST["transferToEmpName"]) ? $_POST["transferToEmpName"] : '';
		$transferToMSOGroup		 = $_POST["transferToMSOGroup"];
		$transferToBranchName    = $_POST["transferToBranchName"];
    	$transferToConcernPerson = $_POST["transferToConcernPerson"];
    	$causeofDamage           = $_POST["causeofDamage"];
    	$remarks                 = $_POST["remarks"];
    	$transferToHOEMPID       = $_POST["transferToHOEMPID"];
    	$transferToHOEMPName     = $_POST["transferToHOEMPName"];
    	$transferToDept          = $_POST["transferToDept"];
    	$transferToLostRemarks   = $_POST["transferToLostRemarks"];
    	$transferToMature        = $_POST["transferToMature"];

//////////////////// FETCH MAX TRANSFER ID FROM transfer table////////////////////////////////////////
		$sql_query = "SELECT MAX(TRANSFERID) AS MAXTRANSFERID FROM mobile_transfer";
		$result=$db->query($sql_query);
		$row = mysqli_fetch_array($result);
    	if($db->query($sql_query) == TRUE){ $MAXTRANSFERID  = $row['MAXTRANSFERID']; }
    	else{ echo"ERROR: failed to get transferid from TRANSFER".mysqli_error($db); } 
//////////////////// END of FETCH MAX TRANSFER ID FROM transfer table////////////////////////////////////////
	
		
//////////////////// SET TRANSFER FROM EMPLOYEE END 'TRANSFERSTATUS' = 4 //////////////////////////////////
		$sql_query = "SELECT * FROM mobile_transfer";
		//$result = mysqli_query($db, $sql_query);
		$result=$db->query($sql_query);
		$transfer_id=$MAXTRANSFERID+1;
		if($transferFrom == "Employee End"){ $TRANSFERSTATUS = "4"; }
		else{ $TRANSFERSTATUS = "0"; }
//////////////////// END OF TRANSFER FROM EMPLOYEE END 'TRANSFERSTATUS' = 4 //////////////////////////////////


////////// SET TRANSFER TO STATUS ACCORDING TO TRANSFER LOCATION 'TRANSFERTOSTATUS' /////////////////////// 
		if($transferTo == "Employee End"){ $TRANSFERTOSTATUS = "4"; $DISPATCHTRANSFERSTATUS = "4"; }
		else if($transferTo == "Branch"){ $TRANSFERTOSTATUS = "3"; $DISPATCHTRANSFERSTATUS = "3"; }
		else if($transferTo == "Damage"){ $TRANSFERTOSTATUS = "2"; $DISPATCHTRANSFERSTATUS = "2"; }
		else if($transferTo == "Head Office"){ $TRANSFERTOSTATUS = "5"; $DISPATCHTRANSFERSTATUS = "5"; }
		else if($transferTo == "Lost"){ $TRANSFERTOSTATUS = "6"; $DISPATCHTRANSFERSTATUS = "6"; }
		else if($transferTo == "FG Store"){ $TRANSFERTOSTATUS = "1"; $DISPATCHTRANSFERSTATUS = "1"; }
		else if($transferTo == "Mature"){ $TRANSFERTOSTATUS = "7"; $DISPATCHTRANSFERSTATUS = "7"; }
		else $TRANSFERTOSTATUS = "0";
////////// END OF TRANSFER TO STATUS ACCORDING TO TRANSFER LOCATION 'TRANSFERTOSTATUS' /////////////////////// 


////////////////////////// INSERT INTO MOBILE TRANSFER FOR TRANSFER TO MATURE, LOST, DAMAGE /////////////////////////
        if($transferTo == "Mature" || $transferTo == "Lost" || $transferTo == "Damage"){
                    $sql_query = "INSERT INTO mobile_transfer 
                    (TRANSFERID, TRANSFERFROMEMPID, TRANSFERFROMEMPNAME, TRANSFERBRAND, TRANSFERMODEL, TRANSFERQRCODE, PREVIOUSASSIGNEDDATE, TRANSFERFROMBRANCHNAME, TRANSFERFROMCONCERNPERSON, TRANSFERDATE, TRANSFERFROM, TRANSFERTO, TRANSFERTOTRCODE, TRANSFERTOEMPID, TRANSFERTOEMPNAME, TRANSFERTOMSOGRP, CAUSEOFDAMAGE, REMARKS, TRANSFERTOBRANCHNAME, TRANSFERTOCONCERNPERSON, TRANSFERTOLOSTREMARKS, TRANSFERTOMATURE, TRANSFERSTATUS, TRANSFERTOSTATUS, RECEIVEID, DISPATCHID) 
					VALUES 
                    ($transfer_id ,'$transferFromEmpID' ,'$transferFromEmpName' ,'$transferBrand' ,'$transferModel' ,'$transfer_qr_code' 
                    ,(SELECT ASSIGNDATE FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') 
                    ,'$transferFromBranchName' ,'$concernPerson' ,'$transferDate' ,'$transferFrom' ,'$transferTo' ,'$transferToTRCODE' ,'$transferToEmpID' ,'$transferToEmpName' ,'$transferToMSOGroup' ,'$causeofDamage' ,'$remarks' ,'$transferToBranchName' ,'$transferToConcernPerson' ,'$transferToLostRemarks' ,'$transferToMature' 
                    ,'$TRANSFERSTATUS' 
                    ,'$TRANSFERTOSTATUS' 
                    ,(SELECT RECEIVEID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') 
                    ,(SELECT DISPATCHID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') ); ";    
		            if($db->query($sql_query)==TRUE){/*include "mobile-transfer.php"; */}
                    else{echo"ERROR:Mature, lOST, dAMAGE insert query failed ".mysqli_error($db);} 
                    ////ADJUST ASSIGNSTATUS IN MOBILE DISPATCH////
                    $sql_query = "UPDATE mobile_dispatch SET ASSIGNSTATUS = '0' ,TRANSFERSTATUS = '$DISPATCHTRANSFERSTATUS' WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1' ; ";    
		            if($db->query($sql_query)==TRUE){}
                    else{echo"ERROR:UPDATE ASSIGN STATUS IN DISPATCH IN Mature, LOST, DAMAGE query failed ".mysqli_error($db);} 
                    ////END OF ADJUST ASSIGNSTATUS IN MOBILE DISPATCH////
        }else{}//END OF $transferTo == "Mature", 'LOST', 'DAMAGE' /////////////////
//////////////////////////END OF INSERT INTO MOBILE TRANSFER FOR TRANSFER TO MATURE, LOST, DAMAGE /////////////////////////

//

////////////////////////// INSERT INTO MOBILE TRANSFER FOR TRANSFER TO FG STORE /////////////////////////
        if($transferTo == "FG Store"){
                    $sql_query = "INSERT INTO mobile_transfer 
                    (TRANSFERID, TRANSFERFROMEMPID, TRANSFERFROMEMPNAME, TRANSFERBRAND, TRANSFERMODEL, TRANSFERQRCODE, PREVIOUSASSIGNEDDATE, TRANSFERFROMBRANCHNAME, TRANSFERFROMCONCERNPERSON, TRANSFERDATE, TRANSFERFROM, TRANSFERTO, TRANSFERTOTRCODE, TRANSFERTOEMPID, TRANSFERTOEMPNAME, TRANSFERTOMSOGRP, CAUSEOFDAMAGE, REMARKS, TRANSFERTOBRANCHNAME, TRANSFERTOCONCERNPERSON, TRANSFERTOLOSTREMARKS, TRANSFERTOMATURE, TRANSFERSTATUS, TRANSFERTOSTATUS, RECEIVEID, DISPATCHID) 
					VALUES 
                    ($transfer_id ,'$transferFromEmpID' ,'$transferFromEmpName' ,'$transferBrand' ,'$transferModel' ,'$transfer_qr_code' 
                    ,(SELECT ASSIGNDATE FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') 
                    ,'$transferFromBranchName' ,'$concernPerson' ,'$transferDate' ,'$transferFrom' ,'$transferTo' ,'$transferToTRCODE' ,'$transferToEmpID' ,'$transferToEmpName' ,'$transferToMSOGroup' ,'$causeofDamage' ,'$remarks' ,'$transferToBranchName' ,'$transferToConcernPerson' ,'$transferToLostRemarks' ,'$transferToMature' 
                    ,'$TRANSFERSTATUS' 
                    ,'$TRANSFERTOSTATUS' 
                    ,(SELECT RECEIVEID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') 
                    ,(SELECT DISPATCHID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') ); ";    
		            if($db->query($sql_query)==TRUE){/*include "mobile-transfer.php";*/ }
                    else{echo"ERROR:FG STORE insert query failed ".mysqli_error($db);} 
                    
                    ////ADJUST QUANTITY IN MOBILE RECEIVE////
                    $sql_query = "SELECT RECEIVEID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1'; ";
                    $result = $db->query($sql_query) or die( "failed to get RECEIVEID from dispatch ");
    				$row = mysqli_fetch_array($result);
    				if($db->query($sql_query) == TRUE){
        					$DISPATCHRECEIVEID    = $row['RECEIVEID'];
        					$DISPATCHID           = $row['DISPATCHID'];
    				}else{ echo"ERROR: failed to get receiveID from dispatch".mysqli_error($db);}
                    
                    $sql_query = "UPDATE mobile_receive SET QUANTITY = '1' WHERE RECEIVEID = $DISPATCHRECEIVEID ; ";    
		            if($db->query($sql_query)==TRUE){}
                    else{echo"ERROR:UPDATE ASSIGNSTATUS IN DISPATCH IN FG STORE query failed ".mysqli_error($db);} 
                    ////END OF ADJUST QUANTITY IN MOBILE RECEIVE////
                    
                    ////ADJUST ASSIGNSTATUS IN MOBILE DISPATCH////
                    $sql_query = "UPDATE mobile_dispatch SET ASSIGNSTATUS = '0' WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1' ; ";    
		            if($db->query($sql_query)==TRUE){}
                    else{echo"ERROR:UPDATE ASSIGNSTATUS IN DISPATCH IN FG STORE query failed ".mysqli_error($db);} 
                    ////END OF ADJUST ASSIGNSTATUS IN MOBILE DISPATCH////
        }else{}//END OF $transferTo == "FG Store" /////////////////
//////////////////////////END OF INSERT INTO MOBILE TRANSFER FOR TRANSFER TO FG STORE /////////////////////////

//

////////////////////////// INSERT INTO MOBILE TRANSFER FOR TRANSFER TO EMPLOYEE END /////////////////////////
        if($transferTo == "Employee End"){
                    //CROSSCHECK EMPID/////
                    $sql_query ="SELECT EMPID FROM mobile_dispatch WHERE EMPID ='$transferToEmpID' AND ASSIGNSTATUS = '1' ; ";
				    $result = $db->query($sql_query) or die( "1st query failed");     
                    if($result->num_rows>0){$message = "Already Assigned !!"; echo "<script type='text/javascript'>alert('$message');</script>";/* include "mobile-transfer.php"; */ }
                    else{
                    //END OF CROSS CHECK EMPID QUERY////
            
                            //// INSERTION IN MOBILE TRANSFER /////
                            $sql_query = "INSERT INTO mobile_transfer 
                            (TRANSFERID, TRANSFERFROMEMPID, TRANSFERFROMEMPNAME, TRANSFERBRAND, TRANSFERMODEL, TRANSFERQRCODE, PREVIOUSASSIGNEDDATE, TRANSFERFROMBRANCHNAME, TRANSFERFROMCONCERNPERSON, TRANSFERDATE, TRANSFERFROM, TRANSFERTO, TRANSFERTOTRCODE, TRANSFERTOEMPID, TRANSFERTOEMPNAME, TRANSFERTOMSOGRP, CAUSEOFDAMAGE, REMARKS, TRANSFERTOBRANCHNAME, TRANSFERTOCONCERNPERSON, TRANSFERTOLOSTREMARKS, TRANSFERTOMATURE, TRANSFERSTATUS, TRANSFERTOSTATUS, RECEIVEID, DISPATCHID) 
					        VALUES 
                            ($transfer_id ,'$transferFromEmpID' ,'$transferFromEmpName' ,'$transferBrand' ,'$transferModel' ,'$transfer_qr_code' 
                            ,(SELECT ASSIGNDATE FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') 
                            ,'$transferFromBranchName' ,'$concernPerson' ,'$transferDate' ,'$transferFrom' ,'$transferTo' ,'$transferToTRCODE' ,'$transferToEmpID' ,'$transferToEmpName' ,'$transferToMSOGroup' ,'$causeofDamage' ,'$remarks' ,'$transferToBranchName' ,'$transferToConcernPerson' ,'$transferToLostRemarks' ,'$transferToMature' 
                            ,'$TRANSFERSTATUS' 
                            ,'$TRANSFERTOSTATUS' 
                            ,(SELECT RECEIVEID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') 
                            ,(SELECT DISPATCHID FROM mobile_dispatch WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1') ); ";    
		                    if($db->query($sql_query)==TRUE){ }
                            else{echo"ERROR:EMPLOYEE END insert query failed ".mysqli_error($db);} 
                            //// END OF INSERTION IN MOBILE TRANSFER ////
                    
                   // include "mobile-transfer-employee-insert-in-dispatch.php";
                            ////INSERT NEW EMPLOYEE IN MOBILE DISPATCH////
                            $sql_query = "SELECT MAX(DISPATCHID) AS MAXDISPATCHIDFORTRANSFERINSERT FROM mobile_dispatch";
		                    $result=$db->query($sql_query);
		                    $row = mysqli_fetch_array($result);
    	                    if($db->query($sql_query) == TRUE){ $MAXDISPATCHIDFORTRANSFERINSERT  = $row['MAXDISPATCHIDFORTRANSFERINSERT']; }
    	                    else{ echo"ERROR: failed to get MAXDISPATCHIDFORTRANSFERINSERT from DISPATCH".mysqli_error($db); } 
    	                    
    	                    $sql_query = "SELECT MAX(TRANSFERID) AS MAXTRANSFERID, TRANSFERTOEMPID FROM mobile_transfer";
		                    $result=$db->query($sql_query);
		                    $row = mysqli_fetch_array($result);
    	                    if($db->query($sql_query) == TRUE){ $MAXTRANSFERID  = $row['MAXTRANSFERID']; }
    	                    else{ echo"ERROR: failed to get transferid from TRANSFER".mysqli_error($db); } 
    	                    
    	                    $sql_query = "SELECT * FROM mobile_transfer WHERE TRANSFERID = $MAXTRANSFERID ";
		                    $result=$db->query($sql_query);
		                    $row = mysqli_fetch_array($result);
    	                    if($db->query($sql_query) == TRUE){ $transferToEmpID = $row['TRANSFERTOEMPID']; }
    	                    else{ echo"ERROR: failed to get transferid from TRANSFER".mysqli_error($db); } 
    	                    
                            $sql_query = "SELECT * FROM mobile_dispatch";
					        $result=$db->query($sql_query); 
					        $DISPATCHID = $MAXDISPATCHIDFORTRANSFERINSERT + 1;
					        $sql_query = "INSERT INTO mobile_dispatch (DISPATCHID, ASSIGNDATE, TERRITORY, EMPID, EMPNAME, MSOGRP, ASSIGNSTATUS, LOCATION, BRANCHNAME, CONCERNPERSON, CAUSEOFDAMAGE, REMARKS, HOEMPID, HOEMPNAME, HODEPT, LOSTREMARKS, STATUS, TRANSFERSTATUS, RECEIVEID) 
							        VALUES
							        ($DISPATCHID 
							        ,(SELECT TRANSFERDATE FROM mobile_transfer WHERE TRANSFERTOEMPID  = '$transferToEmpID' ) 
							        ,(SELECT TRANSFERTOTRCODE FROM mobile_transfer WHERE TRANSFERTOEMPID  = '$transferToEmpID' ) 
							        ,(SELECT TRANSFERTOEMPID FROM mobile_transfer WHERE TRANSFERTOEMPID  = '$transferToEmpID' ) 
							        ,(SELECT TRANSFERTOEMPNAME FROM mobile_transfer WHERE TRANSFERTOEMPID  = '$transferToEmpID' ) 
							        ,(SELECT TRANSFERTOMSOGRP FROM mobile_transfer WHERE TRANSFERTOEMPID = '$transferToEmpID')
							        ,'1', 'Employee End'
							        ,' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '
							        ,'4'
							        ,'4'
							        ,(SELECT RECEIVEID FROM mobile_transfer WHERE TRANSFERTOEMPID  = '$transferToEmpID' )  );";
		                    if($db->query($sql_query)==TRUE){}
                            else{echo"ERROR:INSERT NEW EMPLOYEE IN DISPATCH IN EMPLOYEE END query failed ".mysqli_error($db);} 
                            ////END OF INSERT NEW EMPLOYEE IN MOBILE DISPATCH////
                            
                    
                            ////ADJUST ASSIGNSTATUS IN MOBILE DISPATCH////
                            $sql_query = "UPDATE mobile_dispatch SET ASSIGNSTATUS = '0' ,TRANSFERSTATUS = '$DISPATCHTRANSFERSTATUS' WHERE EMPID = '$transferFromEmpID' AND ASSIGNSTATUS = '1' ; ";    
		                    if($db->query($sql_query)==TRUE){ /*include "mobile-transfer.php"; */}
                            else{echo"ERROR:UPDATE ASSIGNSTATUS IN DISPATCH IN EMPLOYEE END query failed ".mysqli_error($db);} 
                            ////END OF ADJUST ASSIGNSTATUS IN MOBILE DISPATCH////
                    }///END OF CROSS CHECK////////
                    
        }else{}//END OF $transferTo == "Employee End" /////////////////
//////////////////////////END OF INSERT INTO MOBILE TRANSFER FOR TRANSFER TO EMPLOYEE END /////////////////////////

}else{ /*echo"ERROR: transfer selection failed ".mysqli_error($db); */} /////isset($_POST['transfer']) ////////////////////


?>	
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl.carousel/assets/owl.carousel.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/colorbox/example1/colorbox.css" rel="stylesheet" type="text/css" >
    <link href="assets/libraries/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/superlist.css" rel="stylesheet" type="text/css" >

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">


    <title>Mobile Management System - Mobile Transfer</title>
    <script>
    function showEmployeeEndLocation(select_item) {

        if (select_item == "Employee End") {
            $('#transferFromEmployee').show();
            $('#transferFromEmpID').show();
            $('#transferFromBranch').hide();
            $('#transferFromHeadOffice').hide();
           // $('#transferFromLost').hide();
        }
        else if (select_item == "Branch") {
            $('#transferFromBranch').show();
            $('#transferFromEmployee').hide();
            $('#transferFromEmployeeInformation').hide();
            $('#transferFromHeadOffice').hide();
          
        }
        else if (select_item == "Head Office") {
            $('#transferFromHeadOffice').show();
            $('#transferFromBranch').hide();
            $('#transferFromEmployee').hide();
            $('#transferFromEmployeeInformation').hide();
        
        }
        else {
            $('#transferFromEmployee').hide();
            $('#transferFromEmployeeInformation').hide();
            $('#transferFromBranch').hide();
            $('#transferFromFGStore').hide();
            $('#transferFromHeadOffice').hide();
          
        }
    }
    
    function showTransferToLocation(select_item) {

        if (select_item == "Employee End") {
            $('#transferToEmployee').show();
            $('#transferToEmpName').show();
            $('#transferToBranch').hide();
            $('#transferToDamage').hide();
            $('#transferToLost').hide();
            $('#transferToHeadOffice').hide();
            $('#transferToMature').hide();
        }
        else if (select_item == "Branch") {
            $('#transferToBranch').show();
            $('#transferToEmployee').hide();
            $('#transferToEmployeeInformation').hide();
            $('#transferToDamage').hide();
            $('#transferToLost').hide();
            $('#transferToHeadOffice').hide();
            $('#transferToMature').hide();
        }
        else if (select_item == "Damage") {
            $('#transferToDamage').show();
            $('#transferToEmployee').hide();
            $('#transferToEmployeeInformation').hide();
            $('#transferToBranch').hide();
            $('#transferToLost').hide();
            $('#transferToHeadOffice').hide();
            $('#transferToMature').hide();
        }
        else if (select_item == "Head Office") {
            $('#transferToHeadOffice').show();
            $('#transferToBranch').hide();
            $('#transferToEmployee').hide();
            $('#transferToEmployeeInformation').hide();
            $('#transferToLost').hide();
            $('#transferToDamage').hide();
            $('#transferToMature').hide();
        }
        else if (select_item == "Lost") {
            $('#transferToLost').show();
            $('#transferToBranch').hide();
            $('#transferToEmployee').hide();
            $('#transferToEmployeeInformation').hide();
            $('#transferToHeadOffice').hide();
            $('#transferToDamage').hide();
            $('#transferToMature').hide();
        }
        else if (select_item == "Mature") {
            $('#transferToMature').show();
            $('#transferToLost').hide();
            $('#transferToBranch').hide();
            $('#transferToEmployee').hide();
            $('#transferToEmployeeInformation').hide();
            $('#transferToHeadOffice').hide();
            $('#transferToDamage').hide();
        }
        else {
            $('#transferToEmployee').hide();
            $('#transferToEmployeeInformation').hide();
            $('#transferToBranch').hide();
            $('#transferToFGStore').hide();
            $('#transferToLost').hide();
            $('#transferToHeadOffice').hide();
            $('#transferToDamage').hide();
            $('#transferToMature').hide();
           
        }
    } 
</script>

    
    
    <script type="text/javascript">
        function confSubmit(transferform) {
                if($("#transferFrom").val() === "" || $("#transferTo").val() === ""){
                        alert("Please complete the form"); 
                }else {
                       if($("#transferFrom").val() === "Employee End"){
                                if($("#transferFromEmpID").val() === ""){
                                        alert("Please complete the form");
                                }else {
                                     /*  if (confirm("Are you sure you want to tramsfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } */
                                }//transferfrom EMPID
                        }//transferfrom employee end
                        else if($("#transferTo").val() === "Employee End"){
                                if($("#transferToTRCODE").val() === "" || $("#transferToEmpID").val() === "" || $("#transferToEmpName").val() === "" || $("#transferToMSOGroup").val() === ""){
                                        alert("Please complete the emplyee information");
                                }else {
                                        if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                                }
                        }//transferto employee end
                        else if($("#transferTo").val() === "Branch"){
                                if($("#transferToBranchName").val() === "" || $("#transferToConcernPerson").val() === ""){
                                        alert("Please complete the branch information");
                        
                                }else {
                                        if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                                }
                        }//branch
                        else if($("#transferTo").val() === "Damage"){
                            if($("#transferTocauseofDamage").val() === "" || $("#remarks").val() === ""){
                                        alert("Please complete the damage information");
                                }else {
                                        if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                                }
                        }// Damage
                        else if($("#transferTo").val() === "Head Office"){
                                if($("#transferToHOEMPID").val() === "" || $("#transferToHOEMPName").val() === "" || $("#transferToDept").val() === ""){
                                        alert("Please complete the head office information");
                                }else {
                                        if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                                }
                        }//head office
                        else if($("#transferTo").val() === "Lost"){
                                if($("#transferToLostRemarks").val() === "" ){
                                        alert("Please complete the Lost information");
                                }else {
                                        if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                                }
                        }//Lost
                        else if($("#transferTo").val() === "Mature"){
                                if($("#transferToMature").val() === "" ){
                                        alert("Please complete the Mature information");
                                }else {
                                        if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                                }
                        }//Mature
                        else {
                            if (confirm("Are you sure you want to transfer this mobile?")) {
                                                form.submit();
                                                alert("Transfered Successfully!");
                                        }
                                        else {
                                                alert("You decided not to transfer this mobile.");
                                        } 
                        }// FG Store
                }// not null condition end
        }//function end
    </script>
    
    


    
    <style type="text/css">
        .gst20{
            margin-top:20px;
        }

        #hdTuto_search{
            display: none;
        }

        .list-gpfrm-list a{
            text-decoration: none !important;
        }

        .list-gpfrm li{
            cursor: pointer;
            padding: 4px 0px;
        }

        .list-gpfrm{
            list-style-type: none;
            background: #d4e8d7;
        }

        .list-gpfrm li:hover{
            color: white;
            background-color: #3d3d3d;
        }
       
        h4{
            color:white;
        }
        .button-but2 {
            background-color: #CC3300;  /* Green */
           /* background-color:#009f8b; */
            width:80%;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 50px;
            
            margin-bottom: 25px;
           /* margin: 4px 6px; */
            cursor: pointer;
            -webkit-transition-duration: 0.4s; /* Safari */
            transition-duration: 0.4s;
        }
        
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
        }
        .button2:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        .button3 {
                border-radius: 12px;
        }
        .boxcolor{
            background-color:#003399;
        }
        
    </style>
</head>


<body class="">

<div class="page-wrapper">
    
    <header class="header header-minimal">
    <div class="header-wrapper">
        <div class="container-fluid">
            <div class="header-inner">
              
                <div class="header-content">
                    <div class="header-bottom">

                    </div><!-- /.header-bottom -->
                </div><!-- /.header-content -->
            </div><!-- /.header-inner -->
        </div><!-- /.container -->
    </div><!-- /.header-wrapper -->

</header><!-- /.header -->




    <div class="main">
        <div class="outer-admin">
            <div class="wrapper-admin">

                <div class="content-admin">
                    <div class="content-admin-wrapper">
                        <div class="content-admin-main">
                            <div class="content-admin-main-inner">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            
   <!-- <div class="page-title">
        <h1>Mobile Transfer</h1>
    </div> -->
                    <a href="admin-home.php">
                        <img src="assets/img/logo1.png" alt="Logo">
                    </a>
                                            
    <div class="page-title">
        <?php  if (isset($_SESSION['username'])) : ?>
			<p style="float:right;"> <a href="login.php" style="color: red;"> logout</a> </p>
            <p style="float:right;">Welcome Mr/Mrs <strong><?php echo $_SESSION['username']; ?> </strong></p> 
		<?php endif ?>
    </div>
                                            
    <div class="row" style="margin-left: 10%; margin-right: 10%;">
         <div class="p50 mb30 center col-sm-3"><a href="mobile-receive.php">
        <!--    <div class="p30 mb30 navcolor center" > -->
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Receive</h4></button>
               <!-- <h4>Mobile Receive </h4>  
           </div> --></a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="mobile-dispatch.php">
          <!--  <div class="p30 mb30 navcolor center" >  -->
                <button class="button-but2 button1 button2 button3 btn btn-primary ">
                    <h4>Mobile Dispatch</h4></button>
            <!--    <h4>Mobile Dispatch </h4>
            </div> --></a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="mobile-transfer.php">
        <!--    <div class="p30 mb30  center" > -->
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                        <h4>Mobile Transfer </h4></button>
                
        <!--   </div>--> </a>
        </div><!-- /.col-* -->

        <div class="p50 mb30 center col-sm-3"><a href="status-report.php">
            <!--    <div class="p30 mb30  center" > -->
                    <button class="button-but2 button1 button2 button3 btn btn-primary " >
                         <h4>Report </h4></button>
                
        <!--   </div>--> </a>

        </div><!-- /.col-* -->
    </div><!-- /.row -->

<div class="col-md-3"> </div>
        <div class="col-md-6">
            <div class="background-white p20 mb50">
                  <h2 class="page-title">Mobile Transfer</h2>
                   <!-- <form method="post" name="transferform" action="test-mobile-transfer-modify-in.php" autocomplete="off"> -->
                        <form method="post" name="transferform" action="#" autocomplete="off">
                        
                        <div class="form-group">
                        <label for="transferFrom">Transfer From</label>
                     <!--   <input type="text" class="form-control" name="transferFrom" id="transferFrom" placeholder="transferFrom"> -->
                         <select class="form-control" name="transferFrom" id="transferFrom" onchange="java_script_:showEmployeeEndLocation(this.options[this.selectedIndex].value)"> <option value="">Select Location</option> 
                           
                            <?php
                                $sql_query = mysqli_query($db,"SELECT DISTINCT LOCATION from mobile_dispatch 
                                where LOCATION = 'Employee End'
                                ORDER BY LOCATION ; ");

                          
                                  
                                while($row = mysqli_fetch_array($sql_query)){
                                echo "<option value='".$row['LOCATION']."'>".$row['LOCATION']."</option>";
                                }
                            ?>
                        </select>
                        </div>  
                        
            <div id="transferFromEmployee" style="display: none"> <!-- Employee End Fields -->


<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
                        <!--  <div class="form-group">
                            <label for="transferFromEmpID">EMP ID</label>  -->
                            <!-- <input type="text" class="form-control" name="empID" id="empID" placeholder="Empliyee ID"> -->
                          <!--      <form id="hdTutoForm" method="POST" action="">
                                    <input type="text" id="transferFromEmpID-list" name="transferFromEmpID" class="form-control" placeholder="Search Name" aria-describedby="basic-addon2">

                                </form>
                            <ul class="list-gpfrm" id="hdTuto_search"></ul>
                            </div>   -->
<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
                            
                            <div class="form-group">
                                <label for="transferFromEmpID">Employee</label>  
                                <input type="text" name="transferFromEmpID" id="transferFromEmpID" class="form-control" autocomplete="off" placeholder="Type Employee ID or Name" />
                            </div>
                            
 <!-- ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  -->                      
                  <!--      <div id="transferFromEmployeeInformation" style="display: none"> -->
                 
			          <!--      <div class="form-group" > --> <!-- style="display: none" -->
                       <!--         <label for="EmpName">EMP Name</label>
                                <input type="text" class="form-control" name="empName" id="transferFromEmpID-list" placeholder="Employee Name"   readonly>   
                            </div> -->

                            <div class="form-group" >
                                <label>Brand</label>
                                <input type="text" class="form-control" name="transferBrand" id="transferBrand" placeholder="Brand" value="<?php echo $row['BRAND']; ?>" readonly> 
                            </div> 
                        
                            <div class="form-group" >
                                <label for="model">Model</label>
                                <input type="text" class="form-control" name="transferModel" id="transferModel" placeholder="Model" readonly>
                            </div>
                        
                            <div class="form-group" >
                                <label>QR Code/IMEI</label>
                                <input type="text" class="form-control" name="transfer_IMEI" id="transfer_IMEI" placeholder="QR Code/IMEI" readonly>
                            </div>
                        
                            <div class="form-group" style="display: none">
                                <label>First Assigned On</label>
                                <input type="text" class="form-control" name="assignedOn" id="assign-list" placeholder="First Assign Date" readonly>
                            </div>
                      <!--  </div> -->
            </div><!-- End of Employee End Fields -->
                        
            <div id="transferFromBranch" style="display: none"> <!-- Branch Fields -->
                            <div class="form-group">
                                <label for="transferFromBranchName">Branch Name</label>
                                <input type="text" class="form-control" name="transferFromBranchName" id="transferFromBranchName" placeholder="Branch Name">
                            </div>
                        
                            <div class="form-group">
                                <label for="concernPerson">Concern Person </label>
                                <input type="text" class="form-control" name="concernPerson" id="concernPerson" placeholder="Concern Person">
                            </div>   
                        
            </div> <!-- End of Branch Fields -->

            <div id="transferFromHeadOffice" style="display: none"> <!-- /.transferFromHeadOffice  -->
                            

                            <div class="form-group">
                                <label for="transferFromHOEMPID">EMP ID</label>
                                <input type="text" class="form-control" name="transferFromHOEMPID" id="transferFromHOEMPID" placeholder="EMP ID" >
                            </div><!-- /.form-group -->
                        
                            <div class="form-group">
                                <label for="transferFromHOEMPName">EMP Name</label>
                                <input type="text" class="form-control" name="transferFromHOEMPName" id="transferFromHOEMPName" placeholder="EMP Name" >
                            </div><!-- /.form-group -->

                            <div class="form-group">
                                <label for="transferFromDept">Department</label>
                                <input type="text" class="form-control" name="transferFromDept" id="transferFromDept" placeholder="Department" >
                            </div><!-- /.form-group -->
            </div> <!-- /.transferFromHeadOffice -->
 
<?php
    date_default_timezone_set("Asia/Dhaka");
?> 
                            
                            <div class="form-group">
                                <label for="">Date</label>
                                <input type="date" class="form-control" name="transferDate" id="transferDate" placeholder="Date" value="<?php echo date('Y-m-d'); ?>" required="" >
                            </div><!-- /.form-group -->
             
           <!-- /.Transfer To -->             
                            <div class="form-group">
                                <label for="transferTo">Transfer To</label>
                     <!--   <input type="text" class="form-control" name="transferTo" id="transferTo" placeholder="To"> -->
                                <select class="form-control" name="transferTo" id="transferTo" onchange="java_script_:showTransferToLocation(this.options[this.selectedIndex].value)"> <option value="">Select Location</option>
                                <?php
                                    $sql_query = mysqli_query($db,"SELECT LOCATIONNAME from location 
                                    where LOCATIONNAME != 'Branch' 
                                    AND LOCATIONNAME != 'Head Office' 
                                    order by LOCATIONNAME ");
                                    while($row = mysqli_fetch_array($sql_query)){
                                        echo "<option value='".$row['LOCATIONNAME']."'>".$row['LOCATIONNAME']."</option>";
                                    }
                                ?>
                                </select>
                            </div>
                     
            <div id="transferToEmployee" style="display: none"> <!-- Employee End Fields -->
                             <div class="form-group">
                                <label for="transferToTerritory">Territory</label>  
                                <input type="text" name="transferToTRCODE" id="transferToTRCODE" class="form-control" autocomplete="off" placeholder="Territory" />
                            </div>

                            <div class="form-group">
                                <label for="transferToEmpID">Emp ID</label>  
                                <input type="text" name="transferToEmpID" id="transferToEmpID" class="form-control" autocomplete="off" placeholder="Employee ID" />
                            </div> <!-- /.transferToEmpID -->

                            <div class="form-group">
                                <label for="transferToEmpName">Emp Name</label>  
                                <input type="text" name="transferToEmpName" id="transferToEmpName" class="form-control" autocomplete="off" placeholder="Employee Name" />
                            </div>

                            <div class="form-group">
                                <label for="transferToMSOGroup">MSO Group</label>  
                                <input type="text" name="transferToMSOGroup" id="transferToMSOGroup" class="form-control" autocomplete="off" placeholder="Group" />
                            </div>
            </div>   <!-- Employee End Fields /.transferToEmpID -->              
                        
            <div id="transferToBranch" style="display: none"> <!-- Branch Fields -->
                            <div class="form-group">
                                <label for="transferToBranchName">Branch Name</label>
                                <input type="text" class="form-control" name="transferToBranchName" id="transferToBranchName" placeholder="Branch Name">
                            </div>
                        
                            <div class="form-group">
                                <label for="transferToconcernPerson">Concern Person </label>
                                <input type="text" class="form-control" name="transferToConcernPerson" id="transferToconcernPerson" placeholder="Concern Person">
                            </div>   
                        
            </div>   <!-- /.transferToBranch -->
                        
            <div id="transferToDamage" style="display: none"> <!-- Damage Fields -->
                            <div class="form-group">
                                <label for="Cause of Damage">Cause of Damage</label>
                                <input type="text" class="form-control" name="causeofDamage" id="transferTocauseofDamage" placeholder="Cause of Damage">
                            </div><!-- /.form-group -->
                        
                            <div class="form-group">
                                <label for="Remarks">Remarks</label>
                                <input type="text" class="form-control" name="remarks" id="remarks" placeholder="Remarks">
                            </div><!-- /.form-group -->
            </div>  <!-- /.transferToDamage -->

            <div id="transferToHeadOffice" style="display: none"> <!-- /.transferFromHeadOffice  -->
                            <div class="form-group">
                                <label for="transferToHOEMPID">EMP ID</label>
                                <input type="text" class="form-control" name="transferToHOEMPID" id="transferToHOEMPID" placeholder="EMP ID" >
                            </div><!-- /.form-group -->
                        
                            <div class="form-group">
                                <label for="transferToHOEMPName">EMP Name</label>
                                <input type="text" class="form-control" name="transferToHOEMPName" id="transferToHOEMPName" placeholder="EMP Name" >
                            </div><!-- /.form-group -->

                            <div class="form-group">
                                <label for="transferToDept">Department</label>
                                <input type="text" class="form-control" name="transferToDept" id="transferToDept" placeholder="Department" >
                            </div><!-- /.form-group -->
            </div> <!-- /.transferFromHeadOffice -->

            <div id="transferToLost" style="display: none"> <!-- /.transferToLost -->
                            <div class="form-group">
                                <label for="transferToLostRemarks">Remarks</label>
                                <input type="text" class="form-control" name="transferToLostRemarks" id="transferToLostRemarks" placeholder="Remarks" >
                            </div><!-- /.form-group -->
            </div> <!-- /.transferToLost -->
            
            <div id="transferToMature" style="display: none"> <!-- /.transferToMature -->
                            <div class="form-group">
                                <label for="transferToMature">Mature</label>
                                <input type="text" class="form-control" name="transferToMature" id="transferToMature" placeholder="Matured" >
                            </div><!-- /.form-group -->
            </div> <!-- /.transferToMature -->
                        
                    <button type="submit" class="btn btn-primary" name="transfer" onClick="confSubmit(this.form);">Transfer</button>
                </form>
            </div>
        </div>
</div>

                                    </div>
                                </div><!-- /.container-fluid -->
                            </div><!-- /.content-admin-main-inner -->
                        </div><!-- /.content-admin-main -->

                        <div class="content-admin-footer">
                            <div class="container-fluid">
                                <div class="content-admin-footer-inner">
                                    <h5 style="text-align:center;">&copy; 2019 All rights are reserved.</h5>
                                </div><!-- /.content-admin-footer-inner -->
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-footer  -->
                    </div><!-- /.content-admin-wrapper -->
                </div><!-- /.content-admin -->
            </div><!-- /.wrapper-admin -->
        </div><!-- /.outer-admin -->
    </div><!-- /.main -->
</div><!-- /.page-wrapper -->

<?php include "footer-script.php"; ?>
    


</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
<!-- Get employee infromation from dispatch & receive table on selected employee for Transfer From-->
<script>
    $(document).ready(function(){
        $('#transferFromEmpID').typeahead({
            source: function(query, result)
            {
                $.ajax({
                    url:"get_TransferFromEMP.php",
                    method:"POST",
                    data:{query:query},
                    dataType:"json",
                    success:function(data)
                    {
                        result($.map(data, function(item){
                            return item;
                        }));
                    }
                })
            }
        });

        var $input = $('#transferFromEmpID');
        $input.change(function() {
            var selectedEmp = $input.typeahead("getActive");
            $.ajax({
                url:"getTransferFromEMPINFO.php",
                method:"POST",
                data: 'transferFromEmpID='+selectedEmp,
                // data:{query:query1},
                dataType:"json",
                success:function(data)
                { 

                    $("#transferBrand").val(data.BRAND);
                    $("#transferModel").val(data.MODEL);
                    $("#transfer_IMEI").val(data.QRCODE);

                }
            });

        });  
    });
</script>
<!-- end of Get employee infromation from dispatch & receive table on selected employee for Transfer From-->


<script>
    //TERRITORY SEARCH
  $(document).ready(function(){
           
      $('#transferToTRCODE').typeahead({
          source: function(query, result)
          {
              $.ajax({
                  url:"mysqTerritory.php",
                  //url:"mysqTransferToTerritory.php",
                  method:"POST",
                  data:{query:query},
                  dataType:"json",
                  success:function(data)
                  {
                      result($.map(data, function(item){
                        console.log(item);
                          return item;
                      }));
                  }
              })
          }
      });

  });
// TERRITORY SEARCH END
  </script>
  
<script>
    //EMPID SEARCH AND FETCH EMPNAME
  $(document).ready(function(){
      $('#transferToEmpID').typeahead({
          source: function(query, result)
          {
              $.ajax({
                  url:"mysql.php",
                  method:"POST",
                  data:{query:query},
                  dataType:"json",
                  success:function(data)
                  {
                      result($.map(data, function(item){
                          return item;
                      }));
                  }
              })
        }
    });

    var $input = $('#transferToEmpID');

    $input.change(function() {
          var selectedEmp = $input.typeahead("getActive");

          $.ajax({
               url:"getTransferToEMPINFO.php",
               method:"POST",
               data: 'transferToEmpID='+selectedEmp,
                // data:{query:query1},
              dataType:"json",
              success:function(data)
              {
              		
                    $("#transferToEmpName").val(data.FFNAME);
                    $("#transferToMSOGroup").val(data.MSOGROUP);
                  //  $("#QRCODE").val(data.QRCODE);

            }
        });
    });
   
  });
   //EMPID SEARCH AND FETCH EMPNAME END
  </script>
