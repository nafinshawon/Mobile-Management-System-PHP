<?php
$connect = mysqli_connect("localhost", "skfmis_skfadmin", "skfstock@2019!", "skfmis_stockmanagedb");
//$request = mysqli_real_escape_string($connect, $_POST["query1"]);
$transferEMPID = $_POST["transferFromEmpID"];

$selectedEmpInfo = explode("-", $transferEMPID);

$selectedEmpId = trim($selectedEmpInfo[0]);



$query = "SELECT * FROM mobile_receive WHERE RECEIVEID = (SELECT RECEIVEID FROM mobile_dispatch WHERE EMPID = " . $selectedEmpId . " AND ASSIGNSTATUS = 1)";

$result = mysqli_query($connect, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 
 $data = mysqli_fetch_assoc($result);
 echo json_encode($data);
}

else echo false;

?>